import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';  // Use BrowserRouter directly (better naming)
import App from './App';
import './index.css';
import { UserProvider } from './Context/UserContext';


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>   {/* Only one Router here */}
      <UserProvider>
        <App />
      </UserProvider>
    </BrowserRouter>
  </StrictMode>
);
