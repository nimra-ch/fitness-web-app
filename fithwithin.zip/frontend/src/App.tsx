import { Routes, Route, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AnimatePresence } from 'framer-motion';

import { TooltipProvider } from "./components/ui/tooltip";
import { Toaster } from "./components/ui/toaster";
import { Toaster as Sonner } from "./components/ui/sonner";

import Navbar from './components/Navbar';
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from './components/Layout';

// Pages
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Signup from './pages/Signup';
import AdminLogin from "./pages/AdminLogin";
import AdminPanel from "./pages/AdminPanel";
import Goals from './pages/GoalSelectionPage';
import CardioPage from './pages/CardioPage';
import MuscleGainPage from './pages/MuscleGainPage';
import WeightLossPage from './pages/WeightLossPage';
import PersonalInfo from './pages/personalInfoPage';
import YogaPage from './pages/YogaPage';
import NotFound from "./pages/NotFound";
import { Profile } from "./pages/Profile";
import Dashboard from './pages/Dashboard';
import Verified from './pages/Verified';
import YogaSession from './pages/YogaSession';
import PricingPage from './pages/PricingPage';
import CardioStart from './pages/CardioStart';
import MuscleSessionPage from './pages/MuscleSessionPage';
import WeightLossSession from './pages/WeightLossSession';

const queryClient = new QueryClient();

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        {/* Public Pages */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/verified" element={<Verified />} />
        <Route path="/pricing" element={<PricingPage />} />

        {/* Admin Routes */}

        {/* Goal-related Pages */}
        <Route path="/GoalSelection" element={<Goals />} />
        <Route path="/yoga/session/:title/:time" element={<YogaSession />} />
        <Route path="/cardio/session/:week/:title/:time" element={<CardioStart />} />
        <Route path="/muscle/session/:week/:title/:time" element={<MuscleSessionPage />} />
        <Route path="/weight/session/:week/:title/:time" element={<WeightLossSession />} />
        <Route path="/personal-info" element={<PersonalInfo />} />
        <Route path="/yoga" element={<YogaPage />} />
        <Route path="/cardio" element={<CardioPage />} />
        <Route path="/muscle-gain" element={<MuscleGainPage />} />
        <Route path="/weight-loss" element={<WeightLossPage />} />

        {/* User Dashboard */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profile" element={<Profile />} />

        {/* Protected Admin Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/admin/dashboard" element={<AdminPanel />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <Navbar />
      <Layout>
        <main className="flex-1">
          <AnimatedRoutes />
        </main>
      </Layout>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
