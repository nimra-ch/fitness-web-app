import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
export const buttonVariants = ({ variant = "default", size = "medium" }: { variant: string, size: string }) => {
  return clsx(
    "btn", // Base class
    variant === "outline" && "btn-outline",
    variant === "ghost" && "btn-ghost",
    size === "small" && "btn-sm",
    size === "medium" && "btn-md",
    size === "large" && "btn-lg"
  )
}
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
