export interface YogaStep {
  description: string;
  image: string;
  video?: string;
  instruction: string;
}

export interface YogaExercise {
  id: string;
  name: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  calories: string;
  image: string;
  video?: string;
  description: string;
  benefits: string[];
  steps: YogaStep[];
  precautions?: string[];
  modifications?: string[];
  breathingTechnique?: string;
}

export const yogaExercises: YogaExercise[] = [
  {
    id: 'sun-salutation',
    name: 'Sun Salutation (Surya Namaskar)',
    duration: '15 mins',
    level: 'Beginner',
    calories: '120',
    image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&q=80&w=1000',
    description: 'A sequence of 12 powerful yoga poses that provide a good cardiovascular workout and improve strength and flexibility.',
    benefits: [
      'Improves blood circulation',
      'Strengthens muscles and joints',
      'Helps with weight loss',
      'Improves flexibility',
      'Calms the mind'
    ],
    steps: [
      {
        description: 'Mountain Pose (Tadasana)',
        image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/E1xym-F_B84',
        instruction: 'Stand tall with feet together, shoulders relaxed, weight evenly distributed through your soles, arms at sides.'
      },
      {
        description: 'Raised Arms Pose (Urdhva Hastasana)',
        image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/4V9IXXLtdZg',
        instruction: 'Inhale, sweep your arms up and back, keeping your biceps parallel to your ears.'
      },
      {
        description: 'Standing Forward Bend (Uttanasana)',
        image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/gyFQJIiMS2s',
        instruction: 'Exhale, fold forward from the hip joints, bringing your hands or fingertips to the floor.'
      },
      {
        description: 'Low Plank (Chaturanga Dandasana)',
        image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/wdEGZJQzzHs',
        instruction: 'Exhale, bend your elbows, and lower your body into a low push-up position.'
      }
    ],
    precautions: [
      'Avoid if you have high blood pressure',
      'Practice with caution if you have back problems',
      'Skip poses that cause pain or discomfort'
    ],
    breathingTechnique: 'Coordinate each movement with breath - inhale when extending, exhale when folding'
  },
  {
    id: 'mindful-flow',
    name: 'Mindful Flow',
    duration: '20 mins',
    level: 'Intermediate',
    calories: '150',
    image: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&q=80&w=1000',
    video: 'https://www.youtube.com/embed/a20hnEm35mk',
    description: 'A gentle yet powerful sequence focusing on breath awareness and mindful movement.',
    benefits: [
      'Reduces stress and anxiety',
      'Improves mind-body connection',
      'Enhances balance and coordination',
      'Increases body awareness',
      'Promotes mental clarity'
    ],
    steps: [
      {
        description: 'Easy Pose (Sukhasana)',
        image: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/zLvJD7iKVhw',
        instruction: 'Sit cross-legged on the floor with your hands resting on your knees. Keep your spine straight and shoulders relaxed.'
      },
      {
        description: 'Cat-Cow Stretch',
        image: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/y39PrKY_4JM',
        instruction: 'Start on hands and knees. Inhale, arch your back and lift your head. Exhale, round your spine and tuck your chin.'
      },
      {
        description: 'Warrior I (Virabhadrasana I)',
        image: 'https://images.unsplash.com/photo-1575052814086-f385e2e2ad1b?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/5rT--p_cLOc',
        instruction: 'Step one foot back, bend your front knee, and raise your arms overhead. Keep your back heel grounded.'
      }
    ],
    modifications: [
      'Use blocks for support in standing poses',
      'Keep knees slightly bent in forward folds',
      'Use wall support for balance poses'
    ],
    breathingTechnique: 'Practice Ujjayi breath throughout the sequence'
  },
  {
    id: 'power-yoga',
    name: 'Power Yoga',
    duration: '30 mins',
    level: 'Advanced',
    calories: '200',
    image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&q=80&w=1000',
    video: 'https://www.youtube.com/embed/7CTMm8z7kOA',
    description: 'A vigorous, fitness-based approach to vinyasa-style yoga, emphasizing strength and flexibility.',
    benefits: [
      'Builds strength and stamina',
      'Improves flexibility',
      'Enhances core stability',
      'Boosts metabolism',
      'Develops mental focus'
    ],
    steps: [
      {
        description: 'Sun Salutations Warm-up',
        image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/ZP34IA0d8LI',
        instruction: 'Begin with 5-10 rounds of dynamic Sun Salutations to warm up the body.'
      },
      {
        description: 'Warrior II (Virabhadrasana II)',
        image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/4Ejz7IgODlU',
        instruction: 'Step your feet wide apart, turn one foot out 90 degrees. Bend your front knee and extend your arms parallel to the ground.'
      },
      {
        description: 'Chaturanga Push-ups',
        image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&q=80&w=1000',
        video: 'https://www.youtube.com/embed/cH0B9P0G4qQ',
        instruction: 'From plank position, lower halfway down keeping elbows close to your body. Perform 5-10 repetitions.'
      }
    ],
    precautions: [
      'Not recommended for beginners',
      'Avoid if you have recent injuries',
      'Practice with an experienced instructor initially'
    ],
    modifications: [
      'Take breaks when needed',
      'Modify challenging poses',
      'Use props for support'
    ],
    breathingTechnique: 'Strong Ujjayi breath synchronized with movements'
  }
];
