export type FitnessGoal = 'cardio' | 'weight-loss' | 'muscle-gain';

export interface UserProfile {
  weight: number;
  height: number;
  gender: 'male' | 'female';
  age: number;
  goal: FitnessGoal;
}