export type WorkoutGoal = 'cardio' | 'weight-loss' | 'muscle-gain' | 'home';
export type Difficulty = 'beginner' | 'intermediate' | 'advanced';
export type IntensityLevel = 'low' | 'moderate' | 'high';

export interface Exercise {
  id: string;
  name: string;
  description: string;
  duration?: string;
  sets?: number;
  reps?: string;
  image: string;
  calories: number;
  difficulty: Difficulty;
  targetMuscles?: string[];
  intensity?: IntensityLevel;
  instructions: string[];
}

export interface DailyWorkout {
  id: string;
  day: string;
  exercises: Exercise[];
  totalDuration: string;
  caloriesBurn: number;
  warmup?: string;
  cooldown?: string;
}

export interface WeeklyPlan {
  weekNumber: number;
  theme: string;
  description: string;
  workouts: DailyWorkout[];
}