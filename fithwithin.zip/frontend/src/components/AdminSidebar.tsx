import React from "react";
import { Link } from "react-router-dom";

const AdminSidebar: React.FC = () => {
  return (
    <div className="w-64 h-screen bg-gray-800 text-white p-5">
      <h2 className="text-2xl font-bold mb-5">Admin Panel</h2>
      <nav>
        <ul className="space-y-4">
          <li><Link to="/admin/users">Users</Link></li>
          <li><Link to="/admin/personal-info">Personal Info</Link></li>
          <li><Link to="/admin/logged-in-users">Logged In Users</Link></li>
          <li><Link to="/admin/contacts">Contacts</Link></li>
        </ul>
      </nav>
    </div>
  );
};

export default AdminSidebar;
