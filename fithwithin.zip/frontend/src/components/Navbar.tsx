import { Link, useNavigate } from 'react-router-dom';
import { Dumbbell } from 'lucide-react';
import { useUser } from '../Context/UserContext';
import axios from 'axios';
const Navbar = () => {
  const { userData, logout } = useUser();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await axios.post(
      'http://localhost:5000/api/users/logout',
      {userId:userData.id},
      {
        
      }
    );
    await logout();
    navigate('/login');
  };

  return (
    <nav className="bg-indigo-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Dumbbell className="h-8 w-8" />
            <span className="text-xl font-bold">FitWithin</span>
          </Link>
          <div className="flex items-center space-x-6">
            <Link to="/" className="hover:text-indigo-200 transition-colors">Home</Link>
            <Link to="/about" className="hover:text-indigo-200 transition-colors">About</Link>
            <Link to="/contact" className="hover:text-indigo-200 transition-colors">Contact</Link>

            {userData && userData.email ? (
              <>
                <span className="text-sm">Hi, {userData.name}</span>
                <button
                  onClick={handleLogout}
                  className="hover:text-indigo-200 transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-indigo-200 transition-colors">Login</Link>
                <Link to="/admin/login" className="hover:text-indigo-200">Admin</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
