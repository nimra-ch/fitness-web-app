import React from 'react';
import { motion } from 'framer-motion';

interface ProgressCardProps {
  title: string;
  value: number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  delay: number;
}

const ProgressCard: React.FC<ProgressCardProps> = ({
  title,
  value,
  unit,
  icon,
  color,
  delay
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className={`bg-white rounded-xl shadow-md p-6 border-l-4 ${color} hover:shadow-lg transition-all duration-300`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-gray-500 text-sm font-medium mb-1">{title}</p>
          <div className="flex items-baseline">
            <p className="text-3xl font-bold">{value}</p>
            <p className="text-gray-500 text-sm ml-1">{unit}</p>
          </div>
        </div>
        <div className={`p-2 rounded-full ${color.replace('border-', 'bg-').replace('-600', '-100')} text-${color.replace('border-', '').replace('-600', '-500')}`}>
          {icon}
        </div>
      </div>
    </motion.div>
  );
};

export default ProgressCard;