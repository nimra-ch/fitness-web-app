import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../Context/UserContext';

interface GoalCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  value: string;
  delay: number;
  imageUrl: string;
}

const GoalCard: React.FC<GoalCardProps> = ({ 
  title, 
  description, 
  icon, 
  color, 
  value,
  delay,
  imageUrl 
}) => {
  const navigate = useNavigate();
  const { userData, setUserData } = useUser();
  
  const handleClick = () => {
    setUserData({ ...userData, goal: value });
    
    if (value === 'yoga') {
      navigate('/yoga');
    } else {
      navigate('/personal-info');
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ 
        scale: 1.05, 
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 10px 10px -5px rgba(0, 0, 0, 0.1)',
        translateY: -10
      }}
      className={`${color} text-white rounded-xl shadow-lg overflow-hidden cursor-pointer relative group`}
      onClick={handleClick}
    >
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
        style={{ backgroundImage: `url(${imageUrl})` }}
      >
        <div className="absolute inset-0 bg-black opacity-60 group-hover:opacity-40 transition-opacity duration-300"></div>
      </div>
      <div className="p-6 flex flex-col h-full relative z-10">
        <div className="mb-4 transform transition-transform duration-300 group-hover:scale-110">
          {icon}
        </div>
        <h3 className="text-xl font-bold mb-2 transform transition-transform duration-300 group-hover:translate-y-[-5px]">{title}</h3>
        <p className="text-sm opacity-90 flex-grow">{description}</p>
        <motion.div 
          className="mt-4 text-sm"
          whileHover={{ x: 5 }}
          transition={{ duration: 0.2 }}
        >
          <span className="inline-flex items-center">
            Choose this goal
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-1 transform transition-transform duration-300 group-hover:translate-x-2" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </span>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default GoalCard;