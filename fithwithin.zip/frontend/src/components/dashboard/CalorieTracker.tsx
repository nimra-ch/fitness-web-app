
import { useState } from "react";
import { Flame, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const CalorieTracker = () => {
  const [calories, setCalories] = useState(0);
  const targetCalories = 2000;
  const progress = (calories / targetCalories) * 100;

  const addCalories = (amount: number) => {
    setCalories(prev => Math.min(prev + amount, targetCalories));
  };

  return (
    <div className="card-shadow p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Flame className="h-6 w-6 text-brand-orange" />
          <h3 className="text-lg font-semibold">Calorie Tracking</h3>
        </div>
        <div className="text-sm text-gray-500">
          {calories} / {targetCalories} kcal
        </div>
      </div>

      <Progress value={progress} className="h-3 mb-4">
        <div 
          className="h-full bg-brand-orange" 
          style={{ width: `${progress}%` }}
        />
      </Progress>

      <div className="grid grid-cols-3 gap-2">
        <Button 
          variant="outline"
          className="border-brand-orange/30 text-brand-orange hover:bg-brand-orange/10"
          onClick={() => addCalories(100)}
        >
          +100 kcal
        </Button>
        <Button 
          variant="outline"
          className="border-brand-orange/30 text-brand-orange hover:bg-brand-orange/10"
          onClick={() => addCalories(250)}
        >
          +250 kcal
        </Button>
        <Button 
          variant="outline"
          className="border-brand-orange/30 text-brand-orange hover:bg-brand-orange/10"
          onClick={() => addCalories(500)}
        >
          +500 kcal
        </Button>
      </div>
    </div>
  );
};

export default CalorieTracker;
