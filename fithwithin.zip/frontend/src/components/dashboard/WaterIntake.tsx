
import { useState } from "react";
import { Droplet, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const WaterIntake = () => {
  const [glasses, setGlasses] = useState(0);
  const targetGlasses = 8;
  const progress = (glasses / targetGlasses) * 100;

  const addGlass = () => {
    if (glasses < targetGlasses) {
      setGlasses(prev => prev + 1);
    }
  };

  return (
    <div className="card-shadow p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Droplet className="h-6 w-6 text-brand-blue" />
          <h3 className="text-lg font-semibold">Water Intake</h3>
        </div>
        <div className="text-sm text-gray-500">
          {glasses} / {targetGlasses} glasses
        </div>
      </div>

      <Progress value={progress} className="h-3 mb-4">
        <div 
          className="h-full bg-brand-blue" 
          style={{ width: `${progress}%` }}
        />
      </Progress>

      <Button 
        className="w-full bg-brand-blue hover:bg-brand-blue/90 text-white gap-2"
        onClick={addGlass}
      >
        <Plus className="h-4 w-4" />
        Add Glass
      </Button>
    </div>
  );
};

export default WaterIntake;
