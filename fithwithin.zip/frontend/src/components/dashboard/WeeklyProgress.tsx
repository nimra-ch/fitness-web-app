
import { BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const data = [
  {
    name: "Mon",
    calories: 1800,
    water: 6,
  },
  {
    name: "Tue",
    calories: 1600,
    water: 7,
  },
  {
    name: "Wed",
    calories: 2100,
    water: 8,
  },
  {
    name: "Thu",
    calories: 1900,
    water: 5,
  },
  {
    name: "Fri",
    calories: 2200,
    water: 6,
  },
  {
    name: "Sat",
    calories: 1500,
    water: 4,
  },
  {
    name: "Sun",
    calories: 1700,
    water: 8,
  },
];

const WeeklyProgress = () => {
  return (
    <Card className="card-shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-6 w-6 text-brand-purple" />
          <CardTitle className="text-lg font-semibold">Weekly Progress</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis 
              dataKey="name" 
              axisLine={false}
              tickLine={false}
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              yAxisId="left"
              axisLine={false}
              tickLine={false}
              style={{ fontSize: '12px' }}
              tickFormatter={(value) => `${value}kcal`}
            />
            <YAxis 
              yAxisId="right"
              orientation="right"
              axisLine={false}
              tickLine={false}
              style={{ fontSize: '12px' }}
              tickFormatter={(value) => `${value}🥤`}
            />
            <Tooltip 
              contentStyle={{ 
                borderRadius: '8px', 
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                border: 'none'
              }} 
            />
            <Legend />
            <Bar 
              yAxisId="left"
              dataKey="calories" 
              name="Calories" 
              fill="#5D4FFF" 
              radius={[4, 4, 0, 0]} 
            />
            <Bar 
              yAxisId="right"
              dataKey="water" 
              name="Water (glasses)" 
              fill="#4D94FF" 
              radius={[4, 4, 0, 0]} 
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default WeeklyProgress;
