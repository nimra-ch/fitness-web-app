import React from 'react';
import { useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const showNavbar = location.pathname !== '/' && !location.pathname.includes('personal-info');

  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow">{children}</main>

      {showNavbar && (
        <footer className="bg-gray-50 border-t">
          <div className="container mx-auto px-4 py-6"></div>
        </footer>
      )}
    </div>
  );
};

export default Layout;

