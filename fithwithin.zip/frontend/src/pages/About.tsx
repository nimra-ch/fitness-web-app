
import { Users, Award, Clock } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl">
            About <span className="text-indigo-600">FitWithin</span>
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Transforming lives through personalized fitness solutions
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <Users className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">10,000+</h3>
            <p className="text-gray-600">Active Members</p>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <Award className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">50+</h3>
            <p className="text-gray-600">Expert Trainers</p>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <Clock className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900">24/7</h3>
            <p className="text-gray-600">Support Available</p>
          </div>
        </div>

        {/* Mission */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            At FitWithin, we believe that everyone deserves access to personalized fitness solutions 
            that work for their unique needs and lifestyle. Our mission is to make health and fitness 
            accessible, enjoyable, and sustainable for everyone, regardless of their starting point.
          </p>
        </div>

          
            </div>
        
        </div>
      
    
  );
};

export default About;