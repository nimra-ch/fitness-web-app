import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PageTransition from "../components/PageTransition";
import axios from "axios";

const WeightLossSession: React.FC = () => {
  const { week, title, time } = useParams<{
    week: string;
    title: string;
    time: string;
  }>();
  const navigate = useNavigate();

  const [seconds, setSeconds] = useState(60);
  const [timerDone, setTimerDone] = useState(false);

  const userId = localStorage.getItem("userId");

  useEffect(() => {
    if (!title || !time) return;
    setSeconds(parseInt(time || "60"));

    const countdown = setInterval(() => {
      setSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(countdown);
          setTimerDone(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countdown);
  }, [title, time]);

  const handleComplete = async () => {
    try {
      await axios.post(
        `http://localhost:5000/api/services/weightloss/complete/${userId}`,
        {
          week: parseInt(week || "1"),
          day: title,
        }
      );
      navigate("/weight-loss");
    } catch (err) {
      console.error("Error marking cardio session as complete", err);
    }
  };

  return (
    <PageTransition>
      <div className="flex flex-col items-center justify-center h-screen px-4 text-center bg-gradient-to-tr from-indigo-600 to-yellow-100">
        <div className="bg-white rounded-2xl shadow-xl max-w-xl w-full p-8">
          <h1 className="text-3xl font-bold text-indigo-700 mb-2">
            {decodeURIComponent(title || "")}
          </h1>
          <p className="text-gray-600 mb-8">
            Get ready for an Weight Loss session. Stay hydrated and push
            yourself!
          </p>

          <div className="text-6xl font-bold text-indigo-900 mb-6">
            {seconds}s
          </div>

          {!timerDone ? (
            <p className="text-gray-500 text-sm">
              Counting down... You can mark complete once timer finishes.
            </p>
          ) : (
            <button
              onClick={handleComplete}
              className="mt-4 bg-indigo-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-indigo-700 transition"
            >
              ✅ Mark as Done
            </button>
          )}
        </div>
      </div>
    </PageTransition>
  );
};

export default WeightLossSession;
