// src/components/LoggedInUsers.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, message, Spin } from 'antd';

interface LoggedInUser { _id: string; username: string; email: string; }

const LoggedInUsers: React.FC = () => {
  const [users, setUsers]     = useState<LoggedInUser[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await axios.get<LoggedInUser[]>(
        'http://localhost:5000/api/admin/logged-in-users',
        {
          withCredentials: true,
          headers: { Authorization: `Bearer ${localStorage.getItem('adminToken')}` }
        }
      );
      console.log('LoggedInUsers ->', res.data);
      setUsers(res.data);
    } catch (err) {
      console.error(err);
      message.error('Could not load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    const iv = setInterval(fetchUsers, 10000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-2xl mb-4">Currently Logged-In Users</h2>
      {loading ? <Spin /> : (
        <Table dataSource={users} rowKey="_id" pagination={false} bordered>
          <Table.Column title="Username" dataIndex="username" key="username" />
          <Table.Column title="Email"    dataIndex="email"    key="email" />
        </Table>
      )}
    </div>
  );
};

export default LoggedInUsers;
