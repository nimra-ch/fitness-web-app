// FRONTEND: Updated CardioPage.tsx

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import PageTransition from "../components/PageTransition";
import ExerciseCard from "../components/ExerciseCard";
import { useUser } from "../Context/UserContext";
import { Flame, ArrowLeft, Calendar, Play } from "lucide-react";
import axios from "axios";

const cardioExercises = [
  {
    id: 1,
    title: "Running Intervals",
    description:
      "Alternate between high intensity running and recovery periods.",
    duration: "20 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/2526878/pexels-photo-2526878.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 2,
    title: "Jump Rope",
    description:
      "Effective cardio workout that improves coordination and burns calories.",
    duration: "15 min",
    difficulty: "Beginner" as const,
    imageUrl:
      "https://images.pexels.com/photos/6389070/pexels-photo-6389070.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 3,
    title: "Cycling Session",
    description:
      "Indoor or outdoor cycling to improve endurance and leg strength.",
    duration: "30 min",
    difficulty: "Beginner" as const,
    imageUrl:
      "https://images.pexels.com/photos/2161449/pexels-photo-2161449.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 4,
    title: "HIIT Circuit",
    description:
      "High-intensity interval training combining cardio and strength exercises.",
    duration: "25 min",
    difficulty: "Advanced" as const,
    imageUrl:
      "https://images.pexels.com/photos/4498522/pexels-photo-4498522.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 5,
    title: "Swimming Laps",
    description: "Full-body workout with minimal impact on joints.",
    duration: "40 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/260598/pexels-photo-260598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 6,
    title: "Stair Climber",
    description:
      "Effective lower body workout that elevates heart rate quickly.",
    duration: "20 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/4164761/pexels-photo-4164761.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
];

const weeklyMealPlan = [
  {
    week: 1,
    meals: {
      breakfast: [
        "Oatmeal with berries and honey",
        "Greek yogurt with granola",
        "Whole grain toast with avocado",
      ],
      snack1: ["Apple with almonds", "Banana with peanut butter"],
      lunch: [
        "Grilled chicken salad",
        "Quinoa bowl with vegetables",
        "Turkey wrap with whole grain bread",
      ],
      snack2: ["Carrot sticks with hummus", "Mixed nuts"],
      dinner: [
        "Grilled fish with sweet potato",
        "Lean beef stir-fry with brown rice",
        "Chicken breast with quinoa",
      ],
    },
  },
  {
    week: 2,
    meals: {
      breakfast: [
        "Smoothie bowl with granola",
        "Egg white omelet with vegetables",
        "Protein pancakes",
      ],
      snack1: ["Orange with walnuts", "Greek yogurt"],
      lunch: [
        "Tuna salad sandwich",
        "Mediterranean bowl",
        "Chicken and avocado wrap",
      ],
      snack2: ["Celery with almond butter", "Rice cakes with hummus"],
      dinner: [
        "Salmon with asparagus",
        "Turkey meatballs with zucchini noodles",
        "Tofu stir-fry",
      ],
    },
  },
  {
    week: 3,
    meals: {
      breakfast: [
        "Chia seed pudding",
        "Cottage cheese with fruit",
        "Breakfast burrito",
      ],
      snack1: ["Protein smoothie", "Trail mix"],
      lunch: [
        "Lentil soup with whole grain bread",
        "Chicken Caesar salad",
        "Buddha bowl",
      ],
      snack2: ["Apple with protein bar", "Edamame"],
      dinner: [
        "Shrimp with brown rice",
        "Lean pork tenderloin",
        "Baked cod with quinoa",
      ],
    },
  },
  {
    week: 4,
    meals: {
      breakfast: [
        "Protein oats",
        "Scrambled eggs with spinach",
        "Whole grain waffles",
      ],
      snack1: ["Pear with cheese", "Rice cakes with nut butter"],
      lunch: [
        "Turkey and avocado sandwich",
        "Chickpea salad",
        "Grilled chicken wrap",
      ],
      snack2: ["Mixed berries with yogurt", "Roasted chickpeas"],
      dinner: [
        "White fish with vegetables",
        "Chicken stir-fry",
        "Turkey burgers",
      ],
    },
  },
];

const weeklyWorkouts = [
  {
    week: 1,
    days: [
      { day: "Monday", workout: "HIIT Cardio - 2 min", intensity: "Moderate" },
      {
        day: "Tuesday",
        workout: "Running Intervals - 25 min",
        intensity: "High",
      },
      {
        day: "Wednesday",
        workout: "Active Recovery/Stretching",
        intensity: "Low",
      },
      { day: "Thursday", workout: "Cycling - 40 min", intensity: "Moderate" },
      { day: "Friday", workout: "Swimming - 30 min", intensity: "Moderate" },
      { day: "Saturday", workout: "Long Run - 45 min", intensity: "Moderate" },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 2,
    days: [
      {
        day: "Monday",
        workout: "Sprint Intervals - 25 min",
        intensity: "High",
      },
      { day: "Tuesday", workout: "Cycling Hills - 35 min", intensity: "High" },
      { day: "Wednesday", workout: "Yoga/Stretching", intensity: "Low" },
      { day: "Thursday", workout: "HIIT Training - 30 min", intensity: "High" },
      {
        day: "Friday",
        workout: "Steady State Cardio - 45 min",
        intensity: "Moderate",
      },
      {
        day: "Saturday",
        workout: "Mixed Cardio - 40 min",
        intensity: "Moderate",
      },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 3,
    days: [
      { day: "Monday", workout: "Tempo Run - 35 min", intensity: "High" },
      {
        day: "Tuesday",
        workout: "Swimming Intervals - 30 min",
        intensity: "High",
      },
      { day: "Wednesday", workout: "Light Jogging - 20 min", intensity: "Low" },
      { day: "Thursday", workout: "Boxing Cardio - 30 min", intensity: "High" },
      { day: "Friday", workout: "Cycling - 45 min", intensity: "Moderate" },
      { day: "Saturday", workout: "Trail Run - 40 min", intensity: "Moderate" },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 4,
    days: [
      { day: "Monday", workout: "HIIT Pyramid - 35 min", intensity: "High" },
      {
        day: "Tuesday",
        workout: "Endurance Run - 45 min",
        intensity: "Moderate",
      },
      { day: "Wednesday", workout: "Recovery Walk - 30 min", intensity: "Low" },
      {
        day: "Thursday",
        workout: "Mixed Intervals - 30 min",
        intensity: "High",
      },
      { day: "Friday", workout: "Stair Climber - 30 min", intensity: "High" },
      {
        day: "Saturday",
        workout: "Long Distance - 50 min",
        intensity: "Moderate",
      },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
];

const CardioPage = () => {
  const navigate = useNavigate();
  const { userData, isDataComplete } = useUser();
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [showMealPlan, setShowMealPlan] = useState(false);
  const [progress, setProgress] = useState<{ week: number; day: string }[]>([]);

  const fetchProgress = async () => {
    try {
      const res = await axios.get(
        `http://localhost:5000/api/services/cardio/${userData.id}/progress`
      );
      console.log(res.data);
      setProgress(res.data.completedDays || []);
    } catch (err) {
      console.error("Failed to load progress", err);
    }
  };

  // const isCompleted = (week: number, day: string) => {
  //   progress.some((entry) =>console.log(entry.week, week, entry.day,day));
  //   return progress.some((entry) => entry.week === week && entry.day === day);
  // };

  const isCompleted = (week: number, dayLabel: string) => {
     const [titlePart, timePart] = dayLabel.split(" - ");
    return progress.some(
      (entry) => entry.week === week && entry.day === titlePart
    );
  };

  useEffect(() => {
    if (!userData.goal) navigate("/");
    if (!isDataComplete) navigate("/personal-info");
    fetchProgress();
  }, [userData.goal, isDataComplete]);

  const currentWeekWorkout = weeklyWorkouts.find(
    (w) => w.week === selectedWeek
  );
  const currentWeekMeal = weeklyMealPlan.find((w) => w.week === selectedWeek);

  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate("/dashboard")}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full"
          >
            <ArrowLeft size={24} />
          </button>
          <Flame size={32} className="text-accent-500 mr-3" />
          <h1 className="text-3xl font-bold">Cardio Training Program</h1>
        </div>

        <div className="flex space-x-4 mb-6">
          {[1, 2, 3, 4].map((week) => (
            <button
              key={week}
              onClick={() => setSelectedWeek(week)}
              className={`px-4 py-2 rounded-lg flex items-center ${
                selectedWeek === week
                  ? "bg-accent-500 text-white"
                  : "bg-gray-100 text-gray-600"
              }`}
            >
              <Calendar size={18} className="mr-2" />
              Week {week}
            </button>
          ))}
        </div>

        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setShowMealPlan(false)}
            className={`px-4 py-2 rounded-lg ${
              !showMealPlan
                ? "bg-accent-500 text-white"
                : "bg-gray-100 text-gray-600"
            }`}
          >
            Workout Plan
          </button>
          <button
            onClick={() => setShowMealPlan(true)}
            className={`px-4 py-2 rounded-lg ${
              showMealPlan
                ? "bg-accent-500 text-white"
                : "bg-gray-100 text-gray-600"
            }`}
          >
            Meal Plan
          </button>
        </div>

        {!showMealPlan ? (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">
              Week {selectedWeek} Workout Schedule
            </h2>
            <div className="grid gap-4">
              {currentWeekWorkout?.days.map((day, index) => (
                <div
                  key={index}
                  className="p-4 rounded-lg bg-gray-50 flex justify-between items-center"
                >
                  <div>
                    <h3 className="font-medium">{day.day}</h3>
                    <p className="text-gray-600">{day.workout}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        day.intensity === "High"
                          ? "bg-red-100 text-red-800"
                          : day.intensity === "Moderate"
                          ? "bg-yellow-100 text-yellow-800"
                          : day.intensity === "Low"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {day.intensity}
                    </span>
                    {isCompleted(selectedWeek, day.workout) ? (
                      <button
                        disabled
                        className="bg-gray-300 text-gray-600 px-3 py-1 rounded cursor-not-allowed"
                      >
                        ✅ Completed
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          const [titlePart, timePart] =
                            day.workout.split(" - ");
                          const seconds = timePart?.includes("min")
                            ? parseInt(timePart) * 60
                            : 0;

                          navigate(
                            `/cardio/session/${selectedWeek}/${encodeURIComponent(
                              titlePart
                            )}/${seconds}`
                          );
                        }}
                        className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                      >
                        <Play size={16} className="inline mr-1" /> Start
                      </button>
                    )}

                    
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">
              Week {selectedWeek} Meal Plan
            </h2>
            <div className="space-y-6">
              {Object.entries(currentWeekMeal?.meals || {}).map(
                ([meal, foods]) => (
                  <div key={meal} className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-medium capitalize mb-2">{meal}</h3>
                    <ul className="list-disc list-inside space-y-1">
                      {foods.map((food, index) => (
                        <li key={index} className="text-gray-600">
                          {food}
                        </li>
                      ))}
                    </ul>
                  </div>
                )
              )}
            </div>
          </div>
        )}

        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Recommended Exercises</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cardioExercises.map((exercise, index) => (
              <ExerciseCard
                key={exercise.id}
                title={exercise.title}
                description={exercise.description}
                duration={exercise.duration}
                difficulty={exercise.difficulty}
                imageUrl={exercise.imageUrl}
                index={index}
              />
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default CardioPage;
