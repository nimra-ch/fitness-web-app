import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";
import { Table, Button, message } from "antd";

interface User {
  _id: string;
  username: string;
  email: string;
}

const UsersPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);

  // Fetch users from the backend
  const fetchUsers = useCallback(async () => {
    try {
      const response = await axios.get<User[]>("http://localhost:5000/api/admin/users", {
        withCredentials: true, // Ensure cookies/session is included
      });
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
      message.error("Failed to load users.");
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Delete user
  const deleteUser = async (id: string) => {
    try {
      console.log(`Attempting to delete user with ID: ${id}`); // Debugging

      const response = await axios.delete(`http://localhost:5000/api/admin/users/${id}`, {
        withCredentials: true,
      });

      console.log("Delete response:", response.data); // Debugging
      message.success("User deleted successfully.");
      fetchUsers(); // Refresh user list
    } catch (error: any) {
      console.error("Error deleting user:", error.response?.data || error);
      message.error(`Failed to delete user: ${error.response?.data?.message || "Server error"}`);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Users</h1>
      <Table dataSource={users} rowKey="_id" bordered>
        <Table.Column title="Username" dataIndex="username" key="username" />
        <Table.Column title="Email" dataIndex="email" key="email" />
        <Table.Column
          title="Actions"
          render={(_, record: User) => (
            <Button danger onClick={() => deleteUser(record._id)}>
              Delete
            </Button>
          )}
        />
      </Table>
    </div>
  );
};

export default UsersPage;
