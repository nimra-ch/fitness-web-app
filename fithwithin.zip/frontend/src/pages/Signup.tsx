import { useState, ChangeEvent, FormEvent, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { User, Mail, Lock } from 'lucide-react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useUser } from '../Context/UserContext';  // Adjust path if needed

const InputField = ({ type, value, onChange, placeholder, icon: Icon, error }: any) => (
  <div className="relative">
    {Icon && (
      <Icon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300" />
    )}
    <input
      type={type}
      value={value}
      onChange={onChange}
      className="w-full pl-10 pr-4 py-3 bg-white/20 border border-gray-300 rounded-lg text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
      placeholder={placeholder}
      required
    />
    {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
  </div>
);

const Signup = () => {
  const [username, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  const { setUserData } = useUser();
  const navigate = useNavigate();

  const validateFields = () => {
    let valid = true;
    const newErrors: Record<string, string> = {};

    if (username.trim().length < 3) {
      newErrors.username = 'Name must be at least 3 characters.';
      valid = false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      newErrors.email = 'Invalid email format.';
      valid = false;
    }

    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;
    if (!passwordRegex.test(password)) {
      newErrors.password = 'Password must be at least 6 characters and contain a number.';
      valid = false;
    }

    setFieldErrors(newErrors);
    return valid;
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (!validateFields()) {
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/api/users/signup', {
        username,
        email,
        password,
      });

      if (response.status === 201) {
        const { userId, token, message } = response.data;

        localStorage.setItem('token', token);
        localStorage.setItem('userId', userId);

        // Update user context data - initialize with basic info from signup
        setUserData(prev => ({
          ...prev,
          id: userId,
          name: username,
          email: email,
          // Other fields keep initial/default values for now
        }));

        toast.success(message || 'Signup successful! Please verify your email.');
        navigate('/GoalSelection');
      }
    } catch (err: any) {
      if (axios.isAxiosError(err)) {
        setError(err.response?.data?.message || 'An error occurred.');
      } else {
        setError('Unexpected error occurred.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80"
          alt="Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black opacity-60"></div>
      </div>

      <div className="relative z-10 w-full max-w-md px-6 py-12 bg-white/10 backdrop-blur-lg rounded-2xl shadow-xl">
        <h2 className="text-3xl font-bold text-white text-center mb-8">Create Account</h2>

        {error && (
          <p className="text-red-500 text-center mb-4">{error}</p>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <InputField
            type="text"
            value={username}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
            placeholder="Name"
            icon={User}
            error={fieldErrors.username}
          />
          <InputField
            type="email"
            value={email}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
            placeholder="Email"
            icon={Mail}
            error={fieldErrors.email}
          />
          <InputField
            type="password"
            value={password}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
            placeholder="Password"
            icon={Lock}
            error={fieldErrors.password}
          />

          <button
            type="submit"
            className={`w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors ${
              loading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            disabled={loading}
          >
            {loading ? 'Signing Up...' : 'Sign Up'}
          </button>
        </form>

        <p className="mt-4 text-center text-white">
          Already have an account?{' '}
          <Link to="/login" className="text-indigo-400 hover:text-indigo-300">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;
