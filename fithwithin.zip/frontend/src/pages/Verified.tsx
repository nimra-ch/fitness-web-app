import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Verified: React.FC = () => {
  const [username, setUsername] = useState<string>('');
  const [message, setMessage] = useState<string>('Verifying...');
  const [loading, setLoading] = useState<boolean>(true);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const token = searchParams.get('token');

    if (token) {
      axios
        .get(`http://localhost:5000/api/users/verify/${token}`)
        .then((res) => {
          const { username } = res.data;
          setUsername(username);
          setMessage('Your email has been successfully verified.');
        })
        .catch((err) => {
          setMessage('Verification failed. This link may be invalid or expired.');
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setMessage('Missing verification token.');
      setLoading(false);
    }
  }, [searchParams]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-yellow-100 px-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md text-center">
        <h1 className="text-2xl font-semibold text-indigo-600 mb-4">
          {loading ? '⏳ Please wait...' : `🎉 Hello${username ? `, ${username}` : ''}!`}
        </h1>
        <p className="text-gray-700 mb-6">{message}</p>

        {!loading && message.includes('successfully') && (
          <button
            onClick={() => navigate('/goalSelection')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-6 rounded-lg transition duration-200"
          >
            Go to Dashboard
          </button>
        )}
      </div>
    </div>
  );
};

export default Verified;
