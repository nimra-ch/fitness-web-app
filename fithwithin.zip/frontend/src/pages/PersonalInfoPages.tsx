import React from "react";

const PersonalInfoPage: React.FC = () => {
  return (
    <div>
      <h1>Personal Information</h1>
      <p>Manage users' personal information here.</p>
    </div>
  );
};

export default PersonalInfoPage;
