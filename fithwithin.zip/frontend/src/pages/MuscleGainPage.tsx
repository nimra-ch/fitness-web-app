import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import PageTransition from "../components/PageTransition";
import ExerciseCard from "../components/ExerciseCard";
import { useUser } from "../Context/UserContext";
import { Flame, ArrowLeft, Calendar, Play } from "lucide-react";
import axios from "axios";

const muscleGainExercises = [
  {
    id: 1,
    title: "Barbell Squats",
    description:
      "Compound lower body exercise targeting quads, hamstrings, and glutes.",
    duration: "45 min",
    difficulty: "Advanced" as const,
    imageUrl:
      "https://images.pexels.com/photos/2261485/pexels-photo-2261485.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 2,
    title: "Deadlifts",
    description:
      "Full-body strength exercise focusing on back, glutes, and hamstrings.",
    duration: "40 min",
    difficulty: "Advanced" as const,
    imageUrl:
      "https://images.pexels.com/photos/416778/pexels-photo-416778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 3,
    title: "Bench Press",
    description: "Chest, shoulders, and triceps strengthening exercise.",
    duration: "35 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/136403/pexels-photo-136403.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 4,
    title: "Pull-Ups",
    description: "Upper back and biceps strengthening bodyweight exercise.",
    duration: "20 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/2261481/pexels-photo-2261481.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 5,
    title: "Overhead Press",
    description: "Shoulder and upper chest strength exercise.",
    duration: "30 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/2261482/pexels-photo-2261482.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 6,
    title: "Barbell Rows",
    description: "Strengthens the back muscles and improves posture.",
    duration: "35 min",
    difficulty: "Intermediate" as const,
    imageUrl:
      "https://images.pexels.com/photos/2261484/pexels-photo-2261484.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
];

const weeklyMealPlan = [
  {
    week: 1,
    meals: {
      breakfast: [
        "Scrambled eggs with spinach and whole grain toast",
        "Protein smoothie with banana and peanut butter",
        "Oats with whey protein and berries",
      ],
      snack1: ["Greek yogurt with almonds", "Cottage cheese with pineapple"],
      lunch: [
        "Grilled chicken breast with quinoa and steamed broccoli",
        "Lean beef stir-fry with mixed vegetables",
        "Turkey sandwich with whole grain bread and avocado",
      ],
      snack2: ["Protein shake", "Mixed nuts and dried fruits"],
      dinner: [
        "Baked salmon with sweet potato and asparagus",
        "Chicken thighs with brown rice and green beans",
        "Tofu stir-fry with vegetables",
      ],
    },
  },
  {
    week: 2,
    meals: {
      breakfast: [
        "Omelette with mushrooms and cheese",
        "Protein pancakes with honey",
        "Smoothie bowl with granola and berries",
      ],
      snack1: ["Boiled eggs", "Hummus with carrot sticks"],
      lunch: [
        "Tuna salad with mixed greens",
        "Grilled pork chops with couscous and salad",
        "Chicken quinoa bowl with veggies",
      ],
      snack2: ["Peanut butter on rice cakes", "Protein bar"],
      dinner: [
        "Steak with roasted vegetables",
        "Shrimp with whole wheat pasta",
        "Lentil curry with brown rice",
      ],
    },
  },
  {
    week: 3,
    meals: {
      breakfast: [
        "Chia pudding with almond milk and fruit",
        "French toast with protein syrup",
        "Smoothie with spinach, banana, and protein powder",
      ],
      snack1: ["Cheese slices with apple", "Trail mix"],
      lunch: [
        "Chicken Caesar salad",
        "Grilled salmon with quinoa",
        "Vegetable stir-fry with tofu",
      ],
      snack2: ["Yogurt with honey and walnuts", "Beef jerky"],
      dinner: [
        "Roast chicken with sweet potato",
        "Pork tenderloin with mashed potatoes",
        "Vegetable and chickpea stew",
      ],
    },
  },
  {
    week: 4,
    meals: {
      breakfast: [
        "Egg muffins with veggies",
        "Protein oatmeal with nuts",
        "Smoothie with berries and chia seeds",
      ],
      snack1: ["Almond butter on celery sticks", "Hard boiled eggs"],
      lunch: [
        "Turkey burger with salad",
        "Grilled chicken wrap",
        "Lentil soup with whole grain bread",
      ],
      snack2: ["Cottage cheese with fruit", "Protein shake"],
      dinner: [
        "Baked cod with steamed veggies",
        "Beef stir-fry with rice noodles",
        "Stuffed peppers with ground turkey",
      ],
    },
  },
];

const weeklyWorkouts = [
  {
    week: 1,
    days: [
      {
        day: "Monday",
        workout: "Upper Body Strength Training (Chest, Shoulders, Triceps)",
        intensity: "High",
      },
      {
        day: "Tuesday",
        workout: "Lower Body Strength Training (Squats, Deadlifts)",
        intensity: "High",
      },
      {
        day: "Wednesday",
        workout: "Rest or Active Recovery (Light Cardio/Stretching)",
        intensity: "Low",
      },
      {
        day: "Thursday",
        workout: "Back and Biceps Strength Training",
        intensity: "High",
      },
      { day: "Friday", workout: "Legs and Core Workout", intensity: "High" },
      {
        day: "Saturday",
        workout: "Full Body Functional Training",
        intensity: "Moderate",
      },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 2,
    days: [
      {
        day: "Monday",
        workout: "Push Day: Chest, Shoulders, Triceps",
        intensity: "High",
      },
      { day: "Tuesday", workout: "Pull Day: Back, Biceps", intensity: "High" },
      {
        day: "Wednesday",
        workout: "Leg Day: Squats, Lunges",
        intensity: "High",
      },
      {
        day: "Thursday",
        workout: "Core and Stability Exercises",
        intensity: "Moderate",
      },
      {
        day: "Friday",
        workout: "Full Body Compound Movements",
        intensity: "High",
      },
      { day: "Saturday", workout: "Active Recovery or Yoga", intensity: "Low" },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 3,
    days: [
      {
        day: "Monday",
        workout: "Upper Body Hypertrophy Training",
        intensity: "High",
      },
      {
        day: "Tuesday",
        workout: "Lower Body Strength Training",
        intensity: "High",
      },
      {
        day: "Wednesday",
        workout: "Active Recovery (Swimming or Light Cardio)",
        intensity: "Low",
      },
      {
        day: "Thursday",
        workout: "Back and Core Strength Training",
        intensity: "High",
      },
      {
        day: "Friday",
        workout: "Legs and Glutes Focused Workout",
        intensity: "High",
      },
      {
        day: "Saturday",
        workout: "Functional Strength and Conditioning",
        intensity: "Moderate",
      },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
  {
    week: 4,
    days: [
      {
        day: "Monday",
        workout: "Push-Pull Hybrid Training",
        intensity: "High",
      },
      {
        day: "Tuesday",
        workout: "Leg Strength and Power Training",
        intensity: "High",
      },
      {
        day: "Wednesday",
        workout: "Mobility and Stretching",
        intensity: "Low",
      },
      {
        day: "Thursday",
        workout: "Upper Body Strength Circuits",
        intensity: "High",
      },
      {
        day: "Friday",
        workout: "Core and Stability Focus",
        intensity: "Moderate",
      },
      {
        day: "Saturday",
        workout: "Full Body Conditioning",
        intensity: "Moderate",
      },
      { day: "Sunday", workout: "Rest Day", intensity: "Rest" },
    ],
  },
];

const MuscleGainPage: React.FC = () => {
  const navigate = useNavigate();
  const { userData, isDataComplete } = useUser();
  const [selectedWeek, setSelectedWeek] = useState(1);
  const [showMealPlan, setShowMealPlan] = useState(false);
    const [progress, setProgress] = useState<{ week: number; day: string }[]>([]);
  
    const fetchProgress = async () => {
    try {
      const res = await axios.get(
        `http://localhost:5000/api/services/muscle/${userData.id}/progress`
      );
      console.log(res.data);
      setProgress(res.data.completedDays || []);
    } catch (err) {
      console.error("Failed to load progress", err);
    }
  };

  // useEffect(() => {
  //   if (!userData.goal) {
  //     navigate("/");
  //   }
  //   if (!isDataComplete) {
  //     navigate("/personal-info");
  //   }
  // }, [userData.goal, isDataComplete, navigate]);

   useEffect(() => {
      if (!userData.goal) navigate("/");
      if (!isDataComplete) navigate("/personal-info");
      fetchProgress();
    }, [userData.goal, isDataComplete]);

  const currentWeekWorkout = weeklyWorkouts.find(
    (w) => w.week === selectedWeek
  );
  const currentWeekMeal = weeklyMealPlan.find((w) => w.week === selectedWeek);
  const isCompleted = (week: number, dayLabel: string) => {
     const [titlePart, timePart] = dayLabel.split(" - ");
    //  console.log(titlePart,timePart)
    // console.log(progress.some(
    //   (entry) => console.log(entry.week,week,entry.day,dayLabel)
    // ))
    return progress.some(
      (entry) => entry.week === week && entry.day === titlePart
    );
  };

  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate("/dashboard")}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <Flame size={32} className="text-accent-500 mr-3" />
          <h1 className="text-3xl font-bold">Muscle Gain Training Program</h1>
        </div>

        <div className="mb-8">
          <div className="flex space-x-4 mb-6">
            {[1, 2, 3, 4].map((week) => (
              <button
                key={week}
                onClick={() => setSelectedWeek(week)}
                className={`px-4 py-2 rounded-lg flex items-center ${
                  selectedWeek === week
                    ? "bg-accent-500 text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                <Calendar size={18} className="mr-2" />
                Week {week}
              </button>
            ))}
          </div>

          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setShowMealPlan(false)}
              className={`px-4 py-2 rounded-lg ${
                !showMealPlan
                  ? "bg-accent-500 text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              Workout Plan
            </button>
            <button
              onClick={() => setShowMealPlan(true)}
              className={`px-4 py-2 rounded-lg ${
                showMealPlan
                  ? "bg-accent-500 text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              Meal Plan
            </button>
          </div>

          {!showMealPlan ? (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4">
                Week {selectedWeek} Workout Schedule
              </h2>
              <div className="grid gap-4">
                {currentWeekWorkout?.days.map((day, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-lg bg-gray-50 flex justify-between items-center"
                  >
                    <div>
                      <h3 className="font-medium">{day.day}</h3>
                      <p className="text-gray-600">{day.workout}</p>
                    </div>
                    <div>
                      <span
                      className={`px-3 mx-5 py-1 rounded-full text-sm ${
                        day.intensity === "High"
                          ? "bg-red-100 text-red-800"
                          : day.intensity === "Moderate"
                          ? "bg-yellow-100 text-yellow-800"
                          : day.intensity === "Low"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {day.intensity}
                    </span>
                    {isCompleted(selectedWeek, day.workout) ? (
                      <button
                        disabled
                        className="bg-gray-300 text-gray-600 px-3 py-1 rounded cursor-not-allowed"
                      >
                        ✅ Completed
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          const [titlePart, timePart] =
                            day.workout.split(" - ");
                          const seconds = timePart?.includes("min")
                            ? parseInt(timePart) * 60
                            : 0;

                          navigate(
                            `/muscle/session/${selectedWeek}/${encodeURIComponent(
                              titlePart
                            )}/${seconds}`
                          );
                        }}
                        className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
                      >
                        <Play size={16} className="inline mr-1" /> Start
                      </button>
                    )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-semibold mb-4">
                Week {selectedWeek} Meal Plan
              </h2>
              <div className="space-y-6">
                {Object.entries(currentWeekMeal?.meals || {}).map(
                  ([meal, foods]) => (
                    <div key={meal} className="bg-gray-50 rounded-lg p-4">
                      <h3 className="font-medium capitalize mb-2">
                        {meal.replace(/([A-Z])/g, " $1").trim()}
                      </h3>
                      <ul className="list-disc list-inside space-y-1">
                        {foods.map((food, index) => (
                          <li key={index} className="text-gray-600">
                            {food}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )
                )}
              </div>
            </div>
          )}
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Recommended Exercises</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {muscleGainExercises.map((exercise, index) => (
              <ExerciseCard
                key={exercise.id}
                title={exercise.title}
                description={exercise.description}
                duration={exercise.duration}
                difficulty={exercise.difficulty}
                imageUrl={exercise.imageUrl}
                index={index}
              />
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default MuscleGainPage;
