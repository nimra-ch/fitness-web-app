// import { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { format } from 'date-fns';
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   PieChart,
//   Pie,
//   Cell
// } from 'recharts';
// import PageTransition from '../components/PageTransition';
// import { ArrowLeft, Users, TrendingUp, Activity } from 'lucide-react';

// const COLORS = ['#8b5cf6', '#14b8a6', '#f97316', '#3b82f6'];

// interface User {
//   id: string;
//   email: string;
//   goal: string;
//   created_at: string;
//   last_sign_in: string;
//   last_logout?: string;
// }

// const AdminPanel = () => {
//   const navigate = useNavigate();
//   const [users, setUsers] = useState<User[]>(() => {
//     const storedUsers = localStorage.getItem('adminUsers');
//     return storedUsers ? JSON.parse(storedUsers) : [];
//   });

//   const [stats, setStats] = useState({
//     totalUsers: 0,
//     newUsersThisMonth: 0,
//     activeUsersToday: 0
//   });

//   const [goalDistribution, setGoalDistribution] = useState([
//     { name: 'Yoga', value: 5 },
//     { name: 'Cardio', value: 8 },
//     { name: 'Muscle Gain', value: 12 },
//     { name: 'Weight Loss', value: 15 }
//   ]);

//   useEffect(() => {
//     const now = new Date();
//     const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
//     const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

//     const newStats = {
//       totalUsers: users.length,
//       newUsersThisMonth: users.filter(user => new Date(user.created_at) >= monthStart).length,
//       activeUsersToday: users.filter(user => new Date(user.last_sign_in) >= dayStart).length
//     };

//     setStats(newStats);

//     const goals = users.reduce((acc, user) => {
//       acc[user.goal] = (acc[user.goal] || 0) + 1;
//       return acc;
//     }, {} as Record<string, number>);


//   }, [users]);

//   const handleRemoveUser = (userId: string) => {
//     const updatedUsers = users.filter(user => user.id !== userId);
//     setUsers(updatedUsers);
//     localStorage.setItem('adminUsers', JSON.stringify(updatedUsers));
//   };

//   return (
//     <PageTransition>
//       <div className="container mx-auto px-4 py-8">
//         <div className="flex items-center mb-8">
//           <button
//             onClick={() => navigate(-1)}
//             className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
//           >
//             <ArrowLeft size={24} />
//           </button>
//           <h1 className="text-3xl font-bold">Admin Dashboard</h1>
//         </div>

//         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
//           <div className="bg-white p-6 rounded-xl shadow-md">
//             <div className="flex items-center justify-between">
//               <div>
//                 <p className="text-gray-500 text-sm">Total Users</p>
//                 <p className="text-2xl font-bold">{stats.totalUsers}</p>
//               </div>
//               <Users className="text-primary-500 w-8 h-8" />
//             </div>
//           </div>

//           <div className="bg-white p-6 rounded-xl shadow-md">
//             <div className="flex items-center justify-between">
//               <div>
//                 <p className="text-gray-500 text-sm">New Users This Month</p>
//                 <p className="text-2xl font-bold">{stats.newUsersThisMonth}</p>
//               </div>
//               <TrendingUp className="text-secondary-500 w-8 h-8" />
//             </div>
//           </div>

//           <div className="bg-white p-6 rounded-xl shadow-md">
//             <div className="flex items-center justify-between">
//               <div>
//                 <p className="text-gray-500 text-sm">Active Users Today</p>
//                 <p className="text-2xl font-bold">{stats.activeUsersToday}</p>
//               </div>
//               <Activity className="text-accent-500 w-8 h-8" />
//             </div>
//           </div>
//         </div>

//         <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
//           <div className="bg-white p-6 rounded-xl shadow-md">
//             <h2 className="text-xl font-semibold mb-4">Goal Distribution</h2>
//             <PieChart width={400} height={300}>
//               <Pie
//                 data={goalDistribution}
//                 cx={200}
//                 cy={150}
//                 innerRadius={60}
//                 outerRadius={100}
//                 fill="#8884d8"
//                 paddingAngle={5}
//                 dataKey="value"
//               >
//                 {goalDistribution.map((_, index) => (
//                   <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                 ))}
//               </Pie>
//               <Tooltip />
//               <Legend />
//             </PieChart>
//           </div>

//           <div className="bg-white p-6 rounded-xl shadow-md">
//             <h2 className="text-xl font-semibold mb-4">User Growth</h2>
//             <BarChart width={400} height={300} data={goalDistribution}>
//               <CartesianGrid strokeDasharray="3 3" />
//               <XAxis dataKey="name" />
//               <YAxis />
//               <Tooltip />
//               <Legend />
//               <Bar dataKey="value" fill="#8b5cf6" />
//             </BarChart>
//           </div>
//         </div>

//         <div className="bg-white rounded-xl shadow-md overflow-hidden">
//           <div className="p-6">
//             <h2 className="text-xl font-semibold mb-4">User Management</h2>
//             <div className="overflow-x-auto">
//               <table className="min-w-full divide-y divide-gray-200">
//                 <thead>
//                   <tr>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Goal</th>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Joined</th>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Login</th>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Logout</th>
//                     <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
//                   </tr>
//                 </thead>
//                 <tbody className="divide-y divide-gray-200">
//                   {users.map((user) => (
//                     <tr key={user.id}>
//                       <td className="px-6 py-4 whitespace-nowrap">{user.email}</td>
//                       <td className="px-6 py-4 whitespace-nowrap capitalize">{user.goal}</td>
//                       <td className="px-6 py-4 whitespace-nowrap">
//                         {format(new Date(user.created_at), 'MMM d, yyyy')}
//                       </td>
//                       <td className="px-6 py-4 whitespace-nowrap">
//                         {format(new Date(user.last_sign_in), 'MMM d, yyyy HH:mm')}
//                       </td>
//                       <td className="px-6 py-4 whitespace-nowrap">
//                         {user.last_logout ? format(new Date(user.last_logout), 'MMM d, yyyy HH:mm') : 'Active'}
//                       </td>
//                       <td className="px-6 py-4 whitespace-nowrap">
//                         <button
//                           onClick={() => handleRemoveUser(user.id)}
//                           className="text-red-600 hover:text-red-900"
//                         >
//                           Remove
//                         </button>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           </div>
//         </div>
//       </div>
//     </PageTransition>
//   );
// };

// export default AdminPanel;


import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell
} from 'recharts';
import PageTransition from '../components/PageTransition';
import { ArrowLeft, Users, TrendingUp, Activity } from 'lucide-react';
import axios from 'axios';

const COLORS = ['#8b5cf6', '#14b8a6', '#f97316', '#3b82f6'];

interface User {
  _id: string;
  email: string;
  goal?: string;
  createdAt: string;
  loginHistory: {
    loginTime: string;
    logoutTime?: string;
  }[];
}

const AdminPanel = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    newUsersThisMonth: 0,
    activeUsersToday: 0
  });
  const [goalDistribution, setGoalDistribution] = useState<any[]>([]);

  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/admin/dashboard');
        const { users, statistics, serviceCounts } = res.data.data;
        console.log(res.data.data)
        setUsers(users);
        setStats(statistics);
        setGoalDistribution(serviceCounts);
      } catch (err) {
        console.error('Failed to fetch dashboard data:', err);
      }
    };

    fetchDashboardData();
  }, []);

  // Remove user
  const handleRemoveUser = async (userId: string) => {
    try {
      await axios.delete(`http://localhost:5000/api/admin/users/${userId}`);
      setUsers(prev => prev.filter(user => user._id !== userId));
    } catch (err) {
      console.error('Failed to delete user:', err);
    }
  };

  const getLastLogin = (user: User) => {
    if (user.loginHistory.length === 0) return null;
    return user.loginHistory[user.loginHistory.length - 1].loginTime;
  };

  const getLastLogout = (user: User) => {
    if (user.loginHistory.length === 0) return null;
    return user.loginHistory[user.loginHistory.length - 1].logoutTime;
  };

  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate(-1)}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Users</p>
                <p className="text-2xl font-bold">{stats.totalUsers}</p>
              </div>
              <Users className="text-primary-500 w-8 h-8" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">New This Month</p>
                <p className="text-2xl font-bold">{stats.newUsersThisMonth}</p>
              </div>
              <TrendingUp className="text-secondary-500 w-8 h-8" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Active Today</p>
                <p className="text-2xl font-bold">{stats.activeUsersToday}</p>
              </div>
              <Activity className="text-accent-500 w-8 h-8" />
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">Service Distribution</h2>
            <PieChart width={400} height={300}>
              <Pie
                data={goalDistribution}
                cx={200}
                cy={150}
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
              >
                {goalDistribution.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">User Growth</h2>
            <BarChart width={400} height={300} data={goalDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8b5cf6" />
            </BarChart>
          </div>
        </div>

        {/* User Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-4">User Management</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Goal</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Joined</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Login</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Logout</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {users.map((user) => (
                    <tr key={user._id}>
                      <td className="px-6 py-4 whitespace-nowrap">{user.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap capitalize">{user.goal || '-'}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {/* {format(new Date(user.createdAt), 'MMM d, yyyy')} */}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getLastLogin(user)
                          ? format(new Date(getLastLogin(user)!), 'MMM d, yyyy HH:mm')
                          : 'Never'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getLastLogout(user)
                          ? format(new Date(getLastLogout(user)!), 'MMM d, yyyy HH:mm')
                          : 'Active'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => handleRemoveUser(user._id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default AdminPanel;
