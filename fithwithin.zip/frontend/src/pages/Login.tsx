import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock } from "lucide-react";
import axios from "axios";
import { useUser } from "../Context/UserContext";


const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const {setUserData,userData} = useUser();

  // Email validation function
  const validateEmail = (email: string) => /\S+@\S+\.\S+/.test(email);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrorMessage(""); // Reset error message

    // Input Validation
    if (!email.trim()) {
      setErrorMessage("Please enter your email.");
      return;
    }
    if (!validateEmail(email)) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.");
      return;
    }

    setLoading(true); // Set loading state

    try {
      const payload = {
        email: email.toLowerCase().trim(), // Normalize email
        password: password.trim(),
      };

      console.log("Sending login request:", payload);

      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        payload,
        {
          headers: { "Content-Type": "application/json" },
        }
      );

      console.log("Login Successful! Server Response:", response.data);

      if (response.status === 200) {
        // Store token in sessionStorage
        localStorage.setItem("token", response.data.token); // safer long-term

        localStorage.setItem("userId", response.data.user.id); // this is needed too

        // Ensure the token is stored
        setUserData({...userData,id:response.data.user.id,name:response.data.user.username,email:response.data.user.email})
        // Redirect to the dashboard after successful login
        navigate("/goalSelection");
      } else {
        setErrorMessage("Failed to log in. Please check your credentials.");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      if (error.response) {
        console.log("Server Response Data:", error.response.data);
        setErrorMessage(
          error.response.data.message || "Invalid email or password."
        );
      } else if (error.request) {
        setErrorMessage("No response from server. Please try again.");
      } else {
        setErrorMessage("Unexpected error occurred. Please try again.");
      }
    } finally {
      setLoading(false); // Reset loading state
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80"
          alt="Background"
          onError={(e) =>
            ((e.target as HTMLImageElement).src =
              "https://via.placeholder.com/150")
          }
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black opacity-60"></div>
      </div>

      {/* Login Form */}
      <div className="relative z-10 w-full max-w-md px-6 py-12 bg-white/10 backdrop-blur-lg rounded-2xl shadow-xl">
        <h2 className="text-3xl font-bold text-white text-center mb-8">
          Welcome Back
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Email Input */}
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white/20 border border-gray-300 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              placeholder="Email"
              required
            />
          </div>

          {/* Password Input */}
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white/20 border border-gray-300 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              placeholder="Password"
              required
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className={`w-full py-3 rounded-lg transition-colors ${
              loading
                ? "bg-gray-500 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-700"
            } text-white`}
            disabled={loading}
          >
            {loading ? "Signing In..." : "Sign In"}
          </button>
        </form>

        {/* Error Message */}
        {errorMessage && (
          <p className="text-red-500 text-center mt-4">{errorMessage}</p>
        )}

        {/* Signup Link */}
        <p className="mt-4 text-center text-white">
          Don&apos;t have an account?{" "}
          <Link to="/signup" className="text-indigo-400 hover:text-indigo-300">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
