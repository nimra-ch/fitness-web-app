import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageTransition from '../components/PageTransition';
import ProgressCard from '../components/ProgressCard';
import { useUser } from '../Context/UserContext';
import { 
  Flame, 
  Dumbbell, 
  Clock, 
  TrendingUp,
  ArrowLeft,
  CogIcon as YogaIcon
} from 'lucide-react';
import { motion } from 'framer-motion';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { 
    userData, 
    setUserData, 
    getWeightStatus, 
    getGoalSuggestion,
    getRecommendedExercises 
  } = useUser();
  
  useEffect(() => {
    if (!userData.goal) {
      navigate('/goalSelection');
    }
    
    if (userData.workouts === 0) {
      setUserData(prev => ({
        ...prev,
        workouts: 3,
        calories: 450,
        minutes: 85,
        progress: 15
      }));
    }
  }, [userData.goal, userData.workouts, navigate, setUserData]);
  
  const goalRoutes = {
    yoga: '/yoga',
    cardio: '/cardio',
    'muscle-gain': '/muscle-gain',
    'weight-loss': '/weight-loss'
  };
  
  const goalTitles = {
    yoga: 'Yoga',
    cardio: 'Cardio',
    'muscle-gain': 'Muscle Gain',
    'weight-loss': 'Weight Loss'
  };
  
  const getGoalIcon = () => {
    switch (userData.goal) {
      case 'yoga':
        return (
          <div className="p-3 bg-primary-100 text-primary-600 rounded-full">
            <YogaIcon size={28} />
          </div>
        );
      case 'cardio':
        return (
          <div className="p-3 bg-accent-100 text-accent-600 rounded-full">
            <Flame size={28} />
          </div>
        );
      case 'muscle-gain':
        return (
          <div className="p-3 bg-secondary-100 text-secondary-600 rounded-full">
            <Dumbbell size={28} />
          </div>
        );
      case 'weight-loss':
        return (
          <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
            <TrendingUp size={28} />
          </div>
        );
      default:
        return null;
    }
  };

  const weightStatus = getWeightStatus();
  const goalSuggestion = getGoalSuggestion();
  const recommendedExercises = getRecommendedExercises();
  
  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center mb-6">
          <button
            onClick={() => navigate('/')}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-3xl font-bold">Your Dashboard</h1>
        </div>

        {weightStatus && (
          <div className={`mb-6 p-4 rounded-lg ${
            weightStatus.includes('healthy') ? 'bg-green-100 text-green-800' :
            weightStatus.includes('underweight') ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>
            <p className="font-medium">{weightStatus}</p>
            {goalSuggestion && (
              <p className="mt-2 text-sm">{goalSuggestion}</p>
            )}
          </div>
        )}
        
        <div className="mb-10">
          <h2 className="text-xl font-semibold mb-4">Your Progress</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <ProgressCard
              title="Workouts Completed"
              value={userData.workouts}
              unit="sessions"
              icon={<Dumbbell size={24} />}
              color="border-primary-600"
              delay={0.1}
            />
            <ProgressCard
              title="Calories Burned"
              value={userData.calories}
              unit="kcal"
              icon={<Flame size={24} />}
              color="border-accent-600"
              delay={0.2}
            />
            <ProgressCard
              title="Total Time"
              value={userData.minutes}
              unit="minutes"
              icon={<Clock size={24} />}
              color="border-secondary-600"
              delay={0.3}
            />
            <ProgressCard
              title="Progress"
              value={userData.progress}
              unit="%"
              icon={<TrendingUp size={24} />}
              color="border-blue-600"
              delay={0.4}
            />
          </div>
        </div>
        
        <div className="mb-10">
          <h2 className="text-xl font-semibold mb-4">Your Plan</h2>
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="md:flex">
              <div className="md:flex-shrink-0">
                <div className="h-48 md:w-48 bg-primary-100 flex items-center justify-center">
                  {getGoalIcon()}
                </div>
              </div>
              <div className="p-8">
                <div className="uppercase tracking-wide text-sm text-primary-600 font-semibold">Current Goal</div>
                <h3 className="mt-1 text-2xl font-semibold">
                  {goalTitles[userData.goal as keyof typeof goalTitles]}
                </h3>
                <p className="mt-2 text-gray-600">
                  {userData.goal === 'yoga' ? 
                    'Focus on flexibility, mindfulness, and balance through yoga practices.' : 
                  userData.goal === 'cardio' ?
                    'Improve cardiovascular health, endurance, and burn calories efficiently.' :
                  userData.goal === 'muscle-gain' ?
                    'Build strength and muscle mass through progressive resistance training.' :
                    'Achieve sustainable weight loss through balanced nutrition and effective workouts.'}
                </p>
                
                {userData.goal !== 'yoga' && (
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-xs text-gray-500 block">Age</span>
                      <span className="font-medium">{userData.age} years</span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-xs text-gray-500 block">Height</span>
                      <span className="font-medium">{userData.height} feet</span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <span className="text-xs text-gray-500 block">Weight</span>
                      <span className="font-medium">{userData.weight} kg</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-10">
          <h2 className="text-xl font-semibold mb-4">Recommended Exercises</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recommendedExercises.map((exercise, index) => (
              <div key={index} className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                <p className="text-gray-800">{exercise}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h2 className="text-xl font-semibold mb-4">Next Steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="card hover:border-primary-500 hover:border cursor-pointer"
              onClick={() => navigate(goalRoutes[userData.goal as keyof typeof goalRoutes])}
            >
              <h3 className="font-semibold text-lg mb-2">Start Your Workout</h3>
              <p className="text-gray-600 mb-4">Begin today's recommended exercises based on your goals.</p>
              <button className="text-primary-600 font-medium">View workout &rarr;</button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="card hover:border-primary-500 hover:border cursor-pointer"
            >
              <h3 className="font-semibold text-lg mb-2">Track Your Progress</h3>
              <p className="text-gray-600 mb-4">Log your workouts and monitor your improvement over time.</p>
              <button className="text-primary-600 font-medium">View progress &rarr;</button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="card hover:border-primary-500 hover:border cursor-pointer"
              onClick={() => navigate('/')}
            >
              <h3 className="font-semibold text-lg mb-2">Update Your Goals</h3>
              <p className="text-gray-600 mb-4">Review and adjust your fitness goals as needed.</p>
              <button className="text-primary-600 font-medium">Modify goals &rarr;</button>
            </motion.div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Dashboard;
