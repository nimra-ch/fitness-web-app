import React from 'react';
import PageTransition from '../components/PageTransition';
import GoalCard from '../components/GoalCard';
import { Flame, Dumbbell, Weight, CogIcon as YogaIcon } from 'lucide-react';

const GoalSelectionPage: React.FC = () => {
  return (
    <PageTransition>
      <div 
        className="min-h-screen flex flex-col justify-center items-center p-4 md:p-8 relative"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=1920)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        
        <div className="text-center max-w-3xl mx-auto mb-12 relative z-10">
          
          <p className="text-xl text-gray-200 mb-8">
            Choose your fitness goal to begin your journey
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl w-full relative z-10">
          <GoalCard
            title="Yoga"
            description="Improve flexibility, balance, and mental clarity through focused yoga practice."
            icon={<YogaIcon size={32} />}
            color="bg-primary-600/90 hover:bg-primary-700"
            value="yoga"
            delay={0.1}
            imageUrl="https://images.pexels.com/photos/3822674/pexels-photo-3822674.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          />
          
          <GoalCard
            title="Cardio"
            description="Boost your heart health and endurance with targeted cardiovascular workouts."
            icon={<Flame size={32} />}
            color="bg-accent-500/90 hover:bg-accent-600"
            value="cardio"
            delay={0.2}
            imageUrl="https://images.pexels.com/photos/2294361/pexels-photo-2294361.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          />
          
          <GoalCard
            title="Muscle Gain"
            description="Build strength and increase muscle mass with progressive resistance training."
            icon={<Dumbbell size={32} />}
            color="bg-secondary-600/90 hover:bg-secondary-700"
            value="muscle-gain"
            delay={0.3}
            imageUrl="https://images.pexels.com/photos/1431282/pexels-photo-1431282.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          />
          
          <GoalCard
            title="Weight Loss"
            description="Achieve a healthy weight through balanced nutrition and effective workouts."
            icon={<Weight size={32} />}
            color="bg-blue-600/90 hover:bg-blue-700"
            value="weight-loss"
            delay={0.4}
            imageUrl="https://images.pexels.com/photos/4498151/pexels-photo-4498151.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          />
        </div>
      </div>
    </PageTransition>
  );
};

export default GoalSelectionPage;
