
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Progress } from "@/components/ui/progress";

export function Profile() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Your Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <Avatar className="h-24 w-24 mx-auto mb-4">
                <AvatarImage src="/placeholder.svg" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <CardTitle>John Doe</CardTitle>
              <CardDescription>Fitness Enthusiast</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p>john.doe@example.com</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Member Since</p>
                  <p>January 2023</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Fitness Level</p>
                  <p>Intermediate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Fitness Statistics</CardTitle>
              <CardDescription>Your progress overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">Current Metrics</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Weight</p>
                      <p className="text-xl font-semibold">75 kg</p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">Height</p>
                      <p className="text-xl font-semibold">180 cm</p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground">BMI</p>
                      <p className="text-xl font-semibold">23.1</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Workout Activity</h3>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Completed workouts this month: 12</p>
                    <p className="text-sm text-muted-foreground">Total hours: 18.5</p>
                    <p className="text-sm text-muted-foreground">Favorite workout type: Strength Training</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Goals</h3>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Increase strength by 15% in 3 months</p>
                    <p className="text-sm text-muted-foreground">Complete a 10K run under 50 minutes</p>
                    <p className="text-sm text-muted-foreground">Reduce body fat to 15%</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Weekly Progress</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Weight Loss Program</span>
                        <span className="text-sm font-medium text-fitness-purple">46%</span>
                      </div>
                      <Progress value={46} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Cardio Plan</span>
                        <span className="text-sm font-medium text-fitness-orange">72%</span>
                      </div>
                      <Progress value={72} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Muscle Gain Program</span>
                        <span className="text-sm font-medium text-fitness-blue">23%</span>
                      </div>
                      <Progress value={23} className="h-2" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
