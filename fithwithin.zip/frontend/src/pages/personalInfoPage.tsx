// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import PageTransition from '../components/PageTransition';
// import { motion } from 'framer-motion';
// import { useUser } from '../Context/UserContext';

// const PersonalInfoPage: React.FC = () => {
//   const navigate = useNavigate();
//   const { userData, setUserData } = useUser();

//   const [formData, setFormData] = useState({
//     name: '',
//     age: '',
//     height: '',
//     weight: '',
//     gender: '',
//   });

//   const [errors, setErrors] = useState({
//     name: '',
//     age: '',
//     height: '',
//     weight: '',
//     gender: '',
//   });

//   // Pre-fill name only; force user to select age, height, weight every time
//   useEffect(() => {
//     if (!userData.goal) {
//       navigate('/');
//       return;
//     }

//     setFormData({
//       name: userData.name || '',
//       age: '',
//       height: '',
//       weight: '',
//       gender: userData.gender || '',
//     });
//   }, [userData, navigate]);

//   const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({ ...prev, [name]: value }));

//     // Clear error on change
//     if (errors[name as keyof typeof errors]) {
//       setErrors((prev) => ({ ...prev, [name]: '' }));
//     }
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();

//     let valid = true;
//     const newErrors = { name: '', age: '', height: '', weight: '', gender: '' };

//     if (!formData.name.trim()) {
//       newErrors.name = 'Name is required';
//       valid = false;
//     }
//     if (!formData.age) {
//       newErrors.age = 'Please select your age';
//       valid = false;
//     }
//     if (!formData.height) {
//       newErrors.height = 'Please select your height';
//       valid = false;
//     }
//     if (!formData.weight) {
//       newErrors.weight = 'Please select your weight';
//       valid = false;
//     }
//     if (!formData.gender) {
//       newErrors.gender = 'Please select your gender';
//       valid = false;
//     }

//     setErrors(newErrors);

//     if (valid) {
//       setUserData({
//         ...userData,
//         name: formData.name.trim(),
//         age: Number(formData.age),
//         height: Number(formData.height),
//         weight: Number(formData.weight),
//         gender: formData.gender,
//       });

//       navigate(userData.goal === 'yoga' ? '/yoga' : '/dashboard');
//     }
//   };

//   // Options
//   const ageOptions = Array.from({ length: 83 }, (_, i) => i + 18); // 18 to 100
//   const heightOptions = Array.from({ length: 26 }, (_, i) => +(4 + i * 0.1).toFixed(1)); // 4.0 to 6.5 ft
//   const weightOptions = Array.from({ length: 116 }, (_, i) => i + 35); // 35 to 150 kg

//   return (
//     <PageTransition>
//       <div
//         className="min-h-screen flex items-center justify-center px-4 py-8 bg-cover bg-center relative"
//         style={{
//           backgroundImage: `url('https://images.unsplash.com/photo-1598970434795-0c54fe7c0642?auto=format&fit=crop&w=1470&q=80')`,
//         }}
//       >
//         <div className="absolute inset-0 bg-black/70 z-0 backdrop-blur-sm" />

//         <motion.div
//           className="w-full max-w-xl bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl p-10 z-10 border border-white/20"
//           initial={{ opacity: 0, y: 20 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.7 }}
//         >
//           <h2 className="text-3xl font-bold text-white mb-6 text-center drop-shadow">
//             Personal Information
//           </h2>

//           <form onSubmit={handleSubmit} className="space-y-6">
//             {/* Name */}
//             <div>
//               <label htmlFor="name" className="block mb-2 font-medium text-white">
//                 Full Name
//               </label>
//               <input
//                 type="text"
//                 name="name"
//                 id="name"
//                 value={formData.name}
//                 onChange={handleChange}
//                 className={`w-full bg-white/20 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition placeholder:text-white/70 hover:shadow-xl ${
//                   errors.name ? 'border-red-500' : 'border-white/30 hover:border-white/50'
//                 }`}
//                 placeholder="John Doe"
//               />
//               {errors.name && <p className="text-sm text-red-300 mt-1">{errors.name}</p>}
//             </div>

//             {/* Age */}
//             <div>
//               <label htmlFor="age" className="block mb-2 font-medium text-white">
//                 Age
//               </label>
//               <select
//                 id="age"
//                 name="age"
//                 value={formData.age}
//                 onChange={handleChange}
//                 className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
//                   errors.age ? 'border-red-500' : 'border-white/30 hover:border-white/50'
//                 }`}
//               >
//                 <option value="" disabled>
//                   Select your age
//                 </option>
//                 {ageOptions.map((age) => (
//                   <option key={age} value={age} className="text-black">
//                     {age}
//                   </option>
//                 ))}
//               </select>
//               {errors.age && <p className="text-sm text-red-300 mt-1">{errors.age}</p>}
//             </div>

//             {/* Height */}
//             <div>
//               <label htmlFor="height" className="block mb-2 font-medium text-white">
//                 Height (feet)
//               </label>
//               <select
//                 id="height"
//                 name="height"
//                 value={formData.height}
//                 onChange={handleChange}
//                 className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
//                   errors.height ? 'border-red-500' : 'border-white/30 hover:border-white/50'
//                 }`}
//               >
//                 <option value="" disabled>
//                   Select your height
//                 </option>
//                 {heightOptions.map((height) => (
//                   <option key={height} value={height} className="text-black">
//                     {height}
//                   </option>
//                 ))}
//               </select>
//               {errors.height && <p className="text-sm text-red-300 mt-1">{errors.height}</p>}
//             </div>

//             {/* Weight */}
//             <div>
//               <label htmlFor="weight" className="block mb-2 font-medium text-white">
//                 Weight (kg)
//               </label>
//               <select
//                 id="weight"
//                 name="weight"
//                 value={formData.weight}
//                 onChange={handleChange}
//                 className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
//                   errors.weight ? 'border-red-500' : 'border-white/30 hover:border-white/50'
//                 }`}
//               >
//                 <option value="" disabled>
//                   Select your weight
//                 </option>
//                 {weightOptions.map((weight) => (
//                   <option key={weight} value={weight} className="text-black">
//                     {weight}
//                   </option>
//                 ))}
//               </select>
//               {errors.weight && <p className="text-sm text-red-300 mt-1">{errors.weight}</p>}
//             </div>

//             {/* Gender */}
//             <div>
//               <label className="block mb-2 font-medium text-white">Gender</label>
//               <div className="flex gap-6">
//                 {['male', 'female'].map((g) => (
//                   <label
//                     key={g}
//                     className="inline-flex items-center text-white gap-2 transition hover:text-blue-300 hover:scale-105"
//                   >
//                     <input
//                       type="radio"
//                       name="gender"
//                       value={g}
//                       checked={formData.gender === g}
//                       onChange={handleChange}
//                       className="text-blue-600 focus:ring-0"
//                     />
//                     {g.charAt(0).toUpperCase() + g.slice(1)}
//                   </label>
//                 ))}
//               </div>
//               {errors.gender && <p className="text-sm text-red-300 mt-1">{errors.gender}</p>}
//             </div>

//             {/* Buttons */}
//             <div className="flex justify-between items-center pt-6">
//               <button
//                 type="button"
//                 onClick={() => navigate('/')}
//                 className="text-white hover:text-blue-300 transition"
//               >
//                 ← Back
//               </button>
//               <motion.button
//                 type="submit"
//                 className="bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg shadow-md hover:bg-blue-700 transition"
//                 whileHover={{ scale: 1.05 }}
//                 whileTap={{ scale: 0.95 }}
//               >
//                 Submit
//               </motion.button>
//             </div>
//           </form>
//         </motion.div>
//       </div>
//     </PageTransition>
//   );
// };

// export default PersonalInfoPage;


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageTransition from '../components/PageTransition';
import { motion } from 'framer-motion';
import { useUser } from '../Context/UserContext';

const PersonalInfoPage: React.FC = () => {
  const navigate = useNavigate();
  const { userData, setUserData } = useUser();

  const [formData, setFormData] = useState({
    name: userData.name,
    age: '',
    height: '',
    weight: '',
    gender: '',
  });

  const [errors, setErrors] = useState({
    name: '',
    age: '',
    height: '',
    weight: '',
    gender: '',
  });

  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (!userData.goal) {
      navigate('/');
      return;
    }

    // Fetch existing info
    const fetchInfo = async () => {
      try {
        const res = await fetch(`http://localhost:5000/api/personal/${userData.id}`);
        if (!res.ok) return;

        const data = await res.json();
        setIsUpdating(true);
        setFormData({
          name: userData.name || '',
          age: data.age.toString(),
          height: (data.height / 30.48).toFixed(1), // cm to ft
          weight: data.weight.toString(),
          gender: data.gender,
        });
      } catch (err) {
        console.error('Failed to fetch personal info', err);
      }
    };

    fetchInfo();
  }, [userData, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    let valid = true;
    const newErrors = { name: '', age: '', height: '', weight: '', gender: '' };

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
      valid = false;
    }
    if (!formData.age) {
      newErrors.age = 'Please select your age';
      valid = false;
    }
    if (!formData.height) {
      newErrors.height = 'Please select your height';
      valid = false;
    }
    if (!formData.weight) {
      newErrors.weight = 'Please select your weight';
      valid = false;
    }
    if (!formData.gender) {
      newErrors.gender = 'Please select your gender';
      valid = false;
    }

    setErrors(newErrors);

    if (!valid) return;

    try {
      const heightInCm = parseFloat(formData.height) * 30.48;

      const res = await fetch('http://localhost:5000/api/personal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: userData.id,
          gender: formData.gender,
          age: Number(formData.age),
          weight: Number(formData.weight),
          height: heightInCm,
          goal: userData.goal,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.message || 'Failed to save info');
        return;
      }

      setUserData({
        ...userData,
        name: formData.name.trim(),
        age: Number(formData.age),
        weight: Number(formData.weight),
        height: heightInCm,
        gender: formData.gender,
        trialEnds: data.trialEnds || null,
      });

      navigate(userData.goal === 'yoga' ? '/yoga' : '/pricing');
    } catch (err) {
      console.error(err);
      alert('Error submitting data.');
    }
  };

  const ageOptions = Array.from({ length: 83 }, (_, i) => i + 18); // 18 to 100
  const heightOptions = Array.from({ length: 26 }, (_, i) => +(4 + i * 0.1).toFixed(1)); // 4.0 to 6.5 ft
  const weightOptions = Array.from({ length: 116 }, (_, i) => i + 35); // 35 to 150 kg

  return (
    <PageTransition>
      <div
        className="min-h-screen flex items-center justify-center px-4 py-8 bg-cover bg-center relative"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1598970434795-0c54fe7c0642?auto=format&fit=crop&w=1470&q=80')`,
        }}
      >
        <div className="absolute inset-0 bg-black/70 z-0 backdrop-blur-sm" />

        <motion.div
          className="w-full max-w-xl bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl p-10 z-10 border border-white/20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center drop-shadow">
            {isUpdating ? 'Update Your Info' : 'Personal Information'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block mb-2 font-medium text-white">Full Name</label>
              <input
                type="text"
                name="name"
                id="name"
                value={formData.name}
                onChange={handleChange}
                className={`w-full bg-white/20 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 transition placeholder:text-white/70 hover:shadow-xl ${
                  errors.name ? 'border-red-500' : 'border-white/30 hover:border-white/50'
                }`}
                placeholder="John Doe"
              />
              {errors.name && <p className="text-sm text-red-300 mt-1">{errors.name}</p>}
            </div>

            {/* Age */}
            <div>
              <label htmlFor="age" className="block mb-2 font-medium text-white">Age</label>
              <select
                id="age"
                name="age"
                value={formData.age}
                onChange={handleChange}
                className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
                  errors.age ? 'border-red-500' : 'border-white/30 hover:border-white/50'
                }`}
              >
                <option value="" disabled>Select your age</option>
                {ageOptions.map((age) => (
                  <option key={age} value={age} className="text-black">
                    {age}
                  </option>
                ))}
              </select>
              {errors.age && <p className="text-sm text-red-300 mt-1">{errors.age}</p>}
            </div>

            {/* Height */}
            <div>
              <label htmlFor="height" className="block mb-2 font-medium text-white">Height (ft)</label>
              <select
                id="height"
                name="height"
                value={formData.height}
                onChange={handleChange}
                className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
                  errors.height ? 'border-red-500' : 'border-white/30 hover:border-white/50'
                }`}
              >
                <option value="" disabled>Select your height</option>
                {heightOptions.map((height) => (
                  <option key={height} value={height} className="text-black">
                    {height}
                  </option>
                ))}
              </select>
              {errors.height && <p className="text-sm text-red-300 mt-1">{errors.height}</p>}
            </div>

            {/* Weight */}
            <div>
              <label htmlFor="weight" className="block mb-2 font-medium text-white">Weight (kg)</label>
              <select
                id="weight"
                name="weight"
                value={formData.weight}
                onChange={handleChange}
                className={`w-full bg-white/30 text-white border px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 hover:shadow-xl ${
                  errors.weight ? 'border-red-500' : 'border-white/30 hover:border-white/50'
                }`}
              >
                <option value="" disabled>Select your weight</option>
                {weightOptions.map((weight) => (
                  <option key={weight} value={weight} className="text-black">
                    {weight}
                  </option>
                ))}
              </select>
              {errors.weight && <p className="text-sm text-red-300 mt-1">{errors.weight}</p>}
            </div>

            {/* Gender */}
            <div>
              <label className="block mb-2 font-medium text-white">Gender</label>
              <div className="flex gap-6">
                {['male', 'female'].map((g) => (
                  <label
                    key={g}
                    className="inline-flex items-center text-white gap-2 transition hover:text-blue-300 hover:scale-105"
                  >
                    <input
                      type="radio"
                      name="gender"
                      value={g}
                      checked={formData.gender === g}
                      onChange={handleChange}
                      className="text-blue-600 focus:ring-0"
                    />
                    {g.charAt(0).toUpperCase() + g.slice(1)}
                  </label>
                ))}
              </div>
              {errors.gender && <p className="text-sm text-red-300 mt-1">{errors.gender}</p>}
            </div>

            {/* Buttons */}
            <div className="flex justify-between items-center pt-6">
              <button
                type="button"
                onClick={() => navigate('/')}
                className="text-white hover:text-blue-300 transition"
              >
                ← Back
              </button>
              <motion.button
                type="submit"
                className="bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg shadow-md hover:bg-blue-700 transition"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {isUpdating ? 'Update Info' : 'Submit'}
              </motion.button>
            </div>
          </form>
        </motion.div>
      </div>
    </PageTransition>
  );
};

export default PersonalInfoPage;
