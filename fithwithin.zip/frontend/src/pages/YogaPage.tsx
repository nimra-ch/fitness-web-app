// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import PageTransition from '../components/PageTransition';
// import ExerciseCard from '../components/ExerciseCard';
// import { useUser } from '../Context/UserContext';
// import { CogIcon as YogaIcon, ArrowLeft } from 'lucide-react';
// import { motion } from 'framer-motion';

// const yogaExercises = {
//   beginner: [
//     {
//       id: 1,
//       title: 'Morning Flow',
//       description: 'Gentle sequence to wake up your body and increase energy for the day.',
//       duration: '15 min',
//       difficulty: 'Beginner' as const,
//       imageUrl: 'https://images.pexels.com/photos/317157/pexels-photo-317157.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 2,
//       title: 'Hatha Yoga',
//       description: 'Traditional practice focusing on alignment and holding poses.',
//       duration: '45 min',
//       difficulty: 'Beginner' as const,
//       imageUrl: 'https://images.pexels.com/photos/4662438/pexels-photo-4662438.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 3,
//       title: 'Restorative Yoga',
//       description: 'Relaxing practice using props to support the body in gentle poses.',
//       duration: '25 min',
//       difficulty: 'Beginner' as const,
//       imageUrl: 'https://images.pexels.com/photos/4325468/pexels-photo-4325468.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 4,
//       title: 'Chair Yoga',
//       description: 'Perfect for beginners, using a chair for support and stability.',
//       duration: '20 min',
//       difficulty: 'Beginner' as const,
//       imageUrl: 'https://images.pexels.com/photos/8436741/pexels-photo-8436741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     }
//   ],
//   intermediate: [
//     {
//       id: 1,
//       title: 'Vinyasa Flow',
//       description: 'Dynamic sequence connecting breath with movement for strength and flexibility.',
//       duration: '30 min',
//       difficulty: 'Intermediate' as const,
//       imageUrl: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 2,
//       title: 'Yin Yoga',
//       description: 'Slow-paced style with poses held for longer periods to target deep tissues.',
//       duration: '40 min',
//       difficulty: 'Intermediate' as const,
//       imageUrl: 'https://images.pexels.com/photos/3822363/pexels-photo-3822363.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 3,
//       title: 'Flow & Restore',
//       description: 'Balanced practice combining flowing sequences with restorative poses.',
//       duration: '45 min',
//       difficulty: 'Intermediate' as const,
//       imageUrl: 'https://images.pexels.com/photos/6698513/pexels-photo-6698513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 4,
//       title: 'Ashtanga Modified',
//       description: 'Modified version of traditional Ashtanga sequence.',
//       duration: '50 min',
//       difficulty: 'Intermediate' as const,
//       imageUrl: 'https://images.pexels.com/photos/8436600/pexels-photo-8436600.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     }
//   ],
//   advanced: [
//     {
//       id: 1,
//       title: 'Power Yoga',
//       description: 'Intense, fitness-based approach to vinyasa-style yoga.',
//       duration: '35 min',
//       difficulty: 'Advanced' as const,
//       imageUrl: 'https://images.pexels.com/photos/4534682/pexels-photo-4534682.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 2,
//       title: 'Advanced Vinyasa',
//       description: 'Complex flowing sequences with advanced postures and transitions.',
//       duration: '60 min',
//       difficulty: 'Advanced' as const,
//       imageUrl: 'https://images.pexels.com/photos/6698516/pexels-photo-6698516.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 3,
//       title: 'Ashtanga Full',
//       description: 'Traditional Ashtanga sequence with advanced postures.',
//       duration: '90 min',
//       difficulty: 'Advanced' as const,
//       imageUrl: 'https://images.pexels.com/photos/6698515/pexels-photo-6698515.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     },
//     {
//       id: 4,
//       title: 'Inversions Flow',
//       description: 'Advanced practice focusing on handstands and other inversions.',
//       duration: '45 min',
//       difficulty: 'Advanced' as const,
//       imageUrl: 'https://images.pexels.com/photos/6698514/pexels-photo-6698514.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//     }
//   ]
// };

// const YogaPage: React.FC = () => {
//   const navigate = useNavigate();
//   const { userData } = useUser();
//   const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

//   useEffect(() => {
//     if (!userData.goal) {
//       navigate('/');
//     }
//   }, [userData.goal, navigate]);

//   const renderLevelSelection = () => (
//     <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
//       {['beginner', 'intermediate', 'advanced'].map((level) => (
//         <motion.div
//           key={level}
//           whileHover={{ scale: 1.03 }}
//           whileTap={{ scale: 0.98 }}
//           className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300"
//           onClick={() => setSelectedLevel(level)}
//         >
//           <div className="h-40 bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center">
//             <YogaIcon size={48} className="text-white" />
//           </div>
//           <div className="p-6">
//             <h3 className="text-xl font-semibold capitalize mb-2">{level} Level</h3>
//             <p className="text-gray-600">
//               {level === 'beginner'
//                 ? 'Perfect for those just starting their yoga journey.'
//                 : level === 'intermediate'
//                 ? 'For practitioners with some experience ready to deepen their practice.'
//                 : 'Advanced poses and sequences for experienced yogis.'}
//             </p>
//           </div>
//         </motion.div>
//       ))}
//     </div>
//   );

//   return (
//     <PageTransition>
//       <div className="container mx-auto px-4 py-8 md:py-12">
//         <div className="flex items-center mb-8">
//           <button
//             onClick={() => selectedLevel ? setSelectedLevel(null) : navigate('/')}
//             className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
//           >
//             <ArrowLeft size={24} />
//           </button>
//           <YogaIcon size={32} className="text-primary-600 mr-3" />
//           <h1 className="text-3xl font-bold">
//             {selectedLevel ? `${selectedLevel.charAt(0).toUpperCase() + selectedLevel.slice(1)} Yoga` : 'Yoga Practice'}
//           </h1>
//         </div>

//         {!selectedLevel ? (
//           <>
//             <p className="text-gray-600 max-w-3xl mb-8">
//               Choose your practice level to discover yoga sequences tailored to your experience.
//               Each level offers unique challenges and opportunities for growth in your yoga journey.
//             </p>
//             {renderLevelSelection()}
//           </>
//         ) : (
//           <>
//             <p className="text-gray-600 max-w-3xl mb-8">
//               {selectedLevel === 'beginner'
//                 ? 'Start your yoga journey with these foundational practices designed for beginners.'
//                 : selectedLevel === 'intermediate'
//                 ? 'Deepen your practice with these intermediate sequences that build strength and flexibility.'
//                 : 'Challenge yourself with advanced poses and complex sequences.'}
//             </p>
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//               {yogaExercises[selectedLevel as keyof typeof yogaExercises].map((exercise, index) => (
//                 <ExerciseCard
//                   key={exercise.id}
//                   title={exercise.title}
//                   description={exercise.description}
//                   duration={exercise.duration}
//                   difficulty={exercise.difficulty}
//                   imageUrl={exercise.imageUrl}
//                   index={index}
//                 />
//               ))}
//             </div>
//           </>
//         )}
//       </div>
//     </PageTransition>
//   );
// };

// export default YogaPage;

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PageTransition from "../components/PageTransition";
import ExerciseCard from "../components/ExerciseCard";
import { useUser } from "../Context/UserContext";
import { CogIcon as YogaIcon, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";
import axios from "axios";

interface Exercise {
  id: number;
  title: string;
  description: string;
  duration: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  imageUrl: string;
}

interface CompletedDay {
  week: number;
  day: string;
}

const yogaExercises = {
  Beginner: [
    {
      id: 1,
      title: "Morning Flow",
      description:
        "Gentle sequence to wake up your body and increase energy for the day.",
      duration: "2 min",
      difficulty: "Beginner" as const,
      imageUrl:
        "https://images.pexels.com/photos/317157/pexels-photo-317157.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 2,
      title: "Hatha Yoga",
      description:
        "Traditional practice focusing on alignment and holding poses.",
      duration: "45 min",
      difficulty: "Beginner" as const,
      imageUrl:
        "https://images.pexels.com/photos/4662438/pexels-photo-4662438.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 3,
      title: "Restorative Yoga",
      description:
        "Relaxing practice using props to support the body in gentle poses.",
      duration: "25 min",
      difficulty: "Beginner" as const,
      imageUrl:
        "https://images.pexels.com/photos/4325468/pexels-photo-4325468.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 4,
      title: "Chair Yoga",
      description:
        "Perfect for beginners, using a chair for support and stability.",
      duration: "20 min",
      difficulty: "Beginner" as const,
      imageUrl:
        "https://images.pexels.com/photos/8436741/pexels-photo-8436741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
  ],
  Intermediate: [
    {
      id: 1,
      title: "Vinyasa Flow",
      description:
        "Dynamic sequence connecting breath with movement for strength and flexibility.",
      duration: "30 min",
      difficulty: "Intermediate" as const,
      imageUrl:
        "https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 2,
      title: "Yin Yoga",
      description:
        "Slow-paced style with poses held for longer periods to target deep tissues.",
      duration: "40 min",
      difficulty: "Intermediate" as const,
      imageUrl:
        "https://images.pexels.com/photos/3822363/pexels-photo-3822363.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 3,
      title: "Flow & Restore",
      description:
        "Balanced practice combining flowing sequences with restorative poses.",
      duration: "45 min",
      difficulty: "Intermediate" as const,
      imageUrl:
        "https://images.pexels.com/photos/6698513/pexels-photo-6698513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 4,
      title: "Ashtanga Modified",
      description: "Modified version of traditional Ashtanga sequence.",
      duration: "50 min",
      difficulty: "Intermediate" as const,
      imageUrl:
        "https://images.pexels.com/photos/8436600/pexels-photo-8436600.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
  ],
  Advanced: [
    {
      id: 1,
      title: "Power Yoga",
      description: "Intense, fitness-based approach to vinyasa-style yoga.",
      duration: "35 min",
      difficulty: "Advanced" as const,
      imageUrl:
        "https://images.pexels.com/photos/4534682/pexels-photo-4534682.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 2,
      title: "Advanced Vinyasa",
      description:
        "Complex flowing sequences with advanced postures and transitions.",
      duration: "60 min",
      difficulty: "Advanced" as const,
      imageUrl:
        "https://images.pexels.com/photos/6698516/pexels-photo-6698516.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 3,
      title: "Ashtanga Full",
      description: "Traditional Ashtanga sequence with advanced postures.",
      duration: "90 min",
      difficulty: "Advanced" as const,
      imageUrl:
        "https://images.pexels.com/photos/6698515/pexels-photo-6698515.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      id: 4,
      title: "Inversions Flow",
      description:
        "Advanced practice focusing on handstands and other inversions.",
      duration: "45 min",
      difficulty: "Advanced" as const,
      imageUrl:
        "https://images.pexels.com/photos/6698514/pexels-photo-6698514.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
  ],
};

const YogaPage: React.FC = () => {
  const navigate = useNavigate();
  const { userData } = useUser();
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [completed, setCompleted] = useState<string[]>([]);
  const userId = userData?.id;

  const fetchCompleted = async () => {
    console.log("Hello",userId)
    if (!userId) return;
    try {
      const res = await axios.get(
        `http://localhost:5000/api/services/yoga/get-progress/${userId}`
      );
      console.log(res.data)
      setCompleted(res.data.completedWorkouts || []);
    } catch (err) {
      console.error("Failed to fetch progress", err);
    }
  };

  const handleStartSession = (title: string, duration: string) => {
    console.log("Starting session for:", title);
    console.log("Original Duration:", duration);

    // Extract number of minutes and convert to seconds
    const minutes = parseInt(duration);
    const seconds = minutes * 60;

    console.log("Duration in seconds:", seconds);

    navigate(`/yoga/session/${encodeURIComponent(title)}/${seconds}`);
  };

  const handleLevelSelection = async (level: string) => {
    if (!userId) return;

    try {
      await axios.post(
        `http://localhost:5000/api/services/yoga/select/${userId}`,
        { level }
      );

      setSelectedLevel(level);
    } catch (err: any) {
      if (
        err.response &&
        err.response.data &&
        err.response.data.message === "You have already selected a yoga level."
      ) {
        // Allow user to proceed anyway if already selected
        setSelectedLevel(level);
      } else {
        console.error("Error selecting yoga level", err);
      }
    }
  };

  const isCompleted = (title: string) => completed.includes(title);

  useEffect(() => {
    
    if (!userData.goal) navigate("/");
    else fetchCompleted();
  }, [userData.goal, navigate]);

  const renderLevelSelection = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {["Beginner", "Intermediate", "Advanced"].map((level) => (
        <motion.div
          key={level}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300"
          // onClick={() => setSelectedLevel(level)}
          onClick={() => handleLevelSelection(level)}
        >
          <div className="h-40 bg-gradient-to-br from-indigo-600 to-yellow-100 flex items-center justify-center">
            <YogaIcon size={48} className="text-white" />
          </div>
          <div className="p-6">
            <h3 className="text-xl font-semibold capitalize mb-2">
              {level} Level
            </h3>
            <p className="text-gray-600">
              {level === "beginner"
                ? "Perfect for those just starting their yoga journey."
                : level === "intermediate"
                ? "For practitioners with some experience ready to deepen their practice."
                : "Advanced poses and sequences for experienced yogis."}
            </p>
          </div>
        </motion.div>
      ))}
    </div>
  );

  return (
    <PageTransition>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center mb-8">
          <button
            onClick={() =>
              selectedLevel ? setSelectedLevel(null) : navigate("/")
            }
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <YogaIcon size={32} className="text-indigo-600 mr-3" />
          <h1 className="text-3xl font-bold">
            {selectedLevel
              ? `${
                  selectedLevel.charAt(0).toUpperCase() + selectedLevel.slice(1)
                } Yoga`
              : "Yoga Practice"}
            <button
              onClick={async () => {
                if (!userId) return;
                try {
                  await axios.post(
                    `http://localhost:5000/api/services/yoga/reset/${userId}`
                  );
                  setSelectedLevel(null);
                  setCompleted([]);
                } catch (err) {
                  console.error("Failed to reset", err);
                }
              }}
              className="ml-auto bg-red-100 text-red-600 text-sm px-4 py-1 rounded hover:bg-red-200 transition"
            >
              Reset
            </button>
          </h1>
        </div>

        {!selectedLevel ? (
          <>
            <p className="text-gray-600 max-w-3xl mb-8">
              Choose your practice level to discover yoga sequences tailored to
              your experience.
            </p>
            {renderLevelSelection()}
          </>
        ) : (
          <>
            <p className="text-gray-600 max-w-3xl mb-8">
              {selectedLevel === "beginner"
                ? "Start your yoga journey with these foundational practices."
                : selectedLevel === "intermediate"
                ? "Deepen your practice with these intermediate sequences."
                : "Challenge yourself with advanced poses and sequences."}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {yogaExercises[selectedLevel as keyof typeof yogaExercises].map(
                (exercise, index) => (
                  <div key={exercise.id} className="relative">
                    <ExerciseCard
                      title={exercise.title}
                      description={exercise.description}
                      duration={exercise.duration}
                      difficulty={exercise.difficulty}
                      imageUrl={exercise.imageUrl}
                      index={index}
                    />
                    <div className="mt-2 flex justify-between items-center px-2">
                      {isCompleted(exercise.title) ? (
                        <span className="text-green-600 text-sm font-medium">
                          ✅ Completed
                        </span>
                      ) : (
                        <button
                          onClick={() =>
                            handleStartSession(
                              exercise.title,
                              exercise.duration
                            )
                          }
                          className="bg-indigo-600 text-white text-sm px-3 py-1 rounded hover:bg-indigo-700 transition"
                        >
                          Start
                        </button>
                      )}
                    </div>
                  </div>
                )
              )}
            </div>
          </>
        )}
      </div>
    </PageTransition>
  );
};

export default YogaPage;
