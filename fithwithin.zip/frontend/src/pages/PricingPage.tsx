// src/pages/PricingPage.tsx
import React, { useState } from "react";
import { motion } from "framer-motion";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  useStripe,
  useElements,
  CardElement,
} from "@stripe/react-stripe-js";
import axios from "axios";
import { useUser } from "../Context/UserContext";

const stripePromise = loadStripe(
  "pk_test_51RlPHJIwg4sujJFrpU35ceX9dMZzv3k9i9VGENht9dOZ1e3Yd0wQ9DSFeRVXfbVXF8sJnDxUyDnT7GyS99K9jpyd00JOk7GOEV"
);

const plans = [
  {
    name: "Cardio",
    description: "Boost your endurance with our heart-pumping cardio routines.",
    price: 2000,
    features: ["HIIT Workouts", "Endurance Training", "Calorie Burn Tracking"],
  },
  {
    name: "Muscle Gain",
    description: "Gain strength with personalized muscle-building programs.",
    price: 3500,
    features: ["Weight Training", "Progressive Overload", "Nutrition Guide"],
  },
  {
    name: "Weight Loss",
    description: "Effective fat-loss routines paired with smart nutrition.",
    price: 2800,
    features: ["Calorie Deficit Plans", "Home Workouts", "Weekly Tracking"],
  },
];

const CheckoutForm = ({
  plan,
  amount,
  onSuccess,
}: {
  plan: string;
  amount: number;
  onSuccess: () => void;
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const { userData } = useUser();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements || !userData?.id) return;

    setLoading(true);

    try {
      const intentRes = await axios.post(
        "http://localhost:5000/api/payments/create-intent",
        {
          userId: userData.id,
          plan,
          amount,
        }
      );

      const result = await stripe.confirmCardPayment(
        intentRes.data.clientSecret,
        {
          payment_method: {
            card: elements.getElement(CardElement)!,
          },
        }
      );

      if (result.error) {
        setError(result.error.message || "Payment failed");
        setLoading(false);
        return;
      }

      await axios.post("http://localhost:5000/api/payments/confirm", {
        userId: userData.id,
        plan,
        amount,
        paymentIntentId: result.paymentIntent?.id,
      });

      setError("");
      onSuccess(); // Move to success screen
    } catch (err: any) {
      setError(err.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <CardElement className="border px-4 py-3 rounded-md" />
      {error && <p className="text-red-500 text-sm">{error}</p>}
      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-2 rounded-md font-medium"
      >
        {loading ? "Processing..." : "Pay Now"}
      </button>
    </form>
  );
};

const PricingPage: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<{
    name: string;
    price: number;
    description: string;
    features: string[];
  } | null>(null);
  const [paid, setPaid] = useState(false);

  return (
    <div className="min-h-screen bg-white px-4 py-12 md:px-8">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-indigo-500">
          Our Pricing Plans
        </h2>
        <p className="text-gray-600 mt-2">
          Choose a plan that suits your fitness goal
        </p>
      </div>

      {!selectedPlan ? (
        <div className="grid gap-8 md:grid-cols-3 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border border-gray-200 rounded-2xl shadow-md hover:shadow-xl transition-shadow duration-300"
            >
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-indigo-500">
                  {plan.name}
                </h3>
                <p className="text-gray-600 mt-2">{plan.description}</p>
                <div className="mt-4 text-3xl font-bold text-gray-800">
                  PKR {plan.price}
                </div>
                <ul className="mt-6 space-y-2 text-sm text-gray-600">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <span className="mr-2 text-indigo-400">✔</span> {feature}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => setSelectedPlan(plan)}
                  className="mt-6 w-full bg-indigo-400 hover:bg-indigo-500 text-white font-medium py-2 rounded-xl transition-colors"
                >
                  Get Started
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      ) : paid ? (
        <div className="flex flex-col items-center justify-center mt-16 space-y-4 bg-green-50 border border-green-200 rounded-2xl px-8 py-10 max-w-xl mx-auto shadow-md">
          <div className="text-5xl">🎉</div>
          <h3 className="text-3xl font-bold text-green-700">
            Payment Successful
          </h3>
          <p className="text-gray-700 text-center">
            You now have full access to the{" "}
            <span className="font-semibold">{selectedPlan.name}</span> plan.
            <br />
            Let’s crush your goals together 💪
          </p>
          <a
            href="/dashboard"
            className="mt-4 inline-block bg-green-600 text-white px-5 py-2 rounded-md hover:bg-green-700 transition"
          >
            Go to Dashboard
          </a>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto items-start">
          {/* Plan Info */}
          <div className="border rounded-xl shadow-md p-6 bg-indigo-50">
            <h3 className="text-2xl font-bold text-indigo-600">
              {selectedPlan.name}
            </h3>
            <p className="text-gray-700 mt-2">{selectedPlan.description}</p>
            <div className="mt-4 text-3xl font-bold text-gray-800">
              PKR {selectedPlan.price}
            </div>
            <ul className="mt-6 space-y-2 text-sm text-gray-700">
              {selectedPlan.features.map((feature, i) => (
                <li key={i} className="flex items-center">
                  <span className="mr-2 text-indigo-400">✔</span> {feature}
                </li>
              ))}
            </ul>
            <button
              onClick={() => setSelectedPlan(null)}
              className="mt-6 text-indigo-600 hover:underline text-sm"
            >
              ← Back to plans
            </button>
          </div>

          {/* Payment Form */}
          <div className="p-6 border rounded-xl shadow-md bg-white">
            <h4 className="text-lg font-medium text-gray-800 mb-4">
              Enter your payment details
            </h4>
            <Elements stripe={stripePromise}>
              <CheckoutForm
                plan={selectedPlan.name}
                amount={selectedPlan.price}
                onSuccess={() => setPaid(true)}
              />
            </Elements>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricingPage;
