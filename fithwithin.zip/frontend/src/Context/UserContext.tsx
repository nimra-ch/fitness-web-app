import React, { createContext, useContext, useState, useEffect } from 'react';

export interface UserData {
  id?: string;
  email?: string;
  goal: string;
  name: string;
  age: number | null;
  height: number | null;
  weight: number | null;
  gender: string;
  workouts: number;
  calories: number;
  minutes: number;
  progress: number;
  lastLogin?: Date;
  trialEnds?: Date;
}

interface UserContextType {
  userData: UserData;
  setUserData: React.Dispatch<React.SetStateAction<UserData>>;
  isDataComplete: boolean;
  calculateBMI: () => number;
  getBMICategory: () => string;
  getWeightStatus: () => string;
  getGoalSuggestion: () => string | null;
  getRecommendedExercises: () => string[];
  logout: () => Promise<void>;
}

const initialUserData: UserData = {
  goal: '',
  name: '',
  email: '',
  age: null,
  height: null,
  weight: null,
  gender: '',
  workouts: 0,
  calories: 0,
  minutes: 0,
  progress: 0,
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userData, setUserData] = useState<UserData>(() => {
    const saved = localStorage.getItem('userData');
    return saved ? JSON.parse(saved) : initialUserData;
  });

  const isDataComplete = Boolean(
    userData.goal &&
    (userData.goal.toLowerCase() === 'yoga' ||
      (userData.name &&
        userData.age !== null &&
        userData.height !== null &&
        userData.weight !== null &&
        userData.gender))
  );

  useEffect(() => {
    localStorage.setItem('userData', JSON.stringify(userData));
  }, [userData]);

  const calculateBMI = (): number => {
    if (!userData.weight || !userData.height) return 0;
    const heightInMeters = userData.height * 0.01; // Assume height is in cm
    return Number((userData.weight / (heightInMeters * heightInMeters)).toFixed(1));
  };

  const getBMICategory = (): string => {
    const bmi = calculateBMI();
    if (bmi < 18.5) return 'underweight';
    if (bmi < 25) return 'normal';
    if (bmi < 30) return 'overweight';
    return 'obese';
  };

  const getWeightStatus = (): string => {
    const category = getBMICategory();
    switch (category) {
      case 'underweight':
        return 'You are underweight';
      case 'normal':
        return 'You are in a healthy range';
      case 'overweight':
        return 'You are overweight';
      case 'obese':
        return 'You are obese';
      default:
        return '';
    }
  };

  const getGoalSuggestion = (): string | null => {
    const category = getBMICategory();
    const goal = userData.goal.toLowerCase();

    if (goal === 'muscle gain' && (category === 'overweight' || category === 'obese')) {
      return "Because of your weight, we recommend focusing on Weight Loss before Muscle Gain.";
    }

    return null;
  };

  const getRecommendedExercises = (): string[] => {
    const goal = userData.goal.toLowerCase();
    switch (goal) {
      case 'yoga':
        return ['Sun Salutation', 'Tree Pose', 'Warrior Pose'];
      case 'cardio':
        return ['Running', 'Jumping Jacks', 'Cycling'];
      case 'muscle gain':
        return ['Push-ups', 'Weight Lifting', 'Squats'];
      case 'weight loss':
        return ['HIIT', 'Jump Rope', 'Burpees'];
      default:
        return [];
    }
  };

  const logout = async () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('userData');
    setUserData(initialUserData);
  };

  return (
    <UserContext.Provider
      value={{
        userData,
        setUserData,
        isDataComplete,
        calculateBMI,
        getBMICategory,
        getWeightStatus,
        getGoalSuggestion,
        getRecommendedExercises,
        logout,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
