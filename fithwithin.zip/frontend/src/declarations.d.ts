declare module "@/components/ui/button";
declare module "@/components/ui/card";
declare module "@/components/ui/progress";
