const mongoose = require('mongoose');

const cardioProgressSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  completedDays: [
    {
      week: Number,
      day: String, // e.g., Monday
    },
  ],
});

module.exports = mongoose.model('CardioProgress', cardioProgressSchema);
