const mongoose = require('mongoose');

const personalInfoSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  gender: { type: String, required: true },
  age:    { type: Number, required: true },
  weight: { type: Number, required: true },
  height: { type: Number, required: true },
  goal:   { type: String, required: true }, // e.g. Weight Loss, Muscle Gain, etc.
  bmi: { type: Number }, // optional
  classification: { type: String }, // e.g. Normal, Overweight, Underweight
}, { timestamps: true });

module.exports = mongoose.model('PersonalInfo', personalInfoSchema);
