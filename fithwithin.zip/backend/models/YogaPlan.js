const mongoose = require('mongoose');

const yogaPlanSchema = new mongoose.Schema({
  level: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Advanced'],
    required: true,
    unique: true,
  },
  workouts: [{ type: String, required: true }],
});

module.exports = mongoose.model('YogaPlan', yogaPlanSchema);
