const mongoose = require('mongoose');

const weightLossPlanSchema = new mongoose.Schema({
  week: Number,
  schedule: [
    {
      day: String,
      activity: String,
      intensity: String, // High, Moderate, Low, Rest
    },
  ],
});

module.exports = mongoose.model('WeightLossPlan', weightLossPlanSchema);
