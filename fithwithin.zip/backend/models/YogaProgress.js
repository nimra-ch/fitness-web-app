const mongoose = require('mongoose');

const yogaProgressSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  selectedLevel: { type: String, required: true },
  completedWorkouts: [{ type: String }],
});

module.exports = mongoose.model('YogaProgress', yogaProgressSchema);
