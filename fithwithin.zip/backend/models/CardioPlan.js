const mongoose = require('mongoose');

const cardioPlanSchema = new mongoose.Schema({
  week: Number,
  schedule: [
    {
      day: String,
      activity: String,
      intensity: String, // e.g., Low, Moderate, High, Rest
    },
  ],
});

module.exports = mongoose.model('CardioPlan', cardioPlanSchema);
