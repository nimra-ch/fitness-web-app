const mongoose = require('mongoose');

const progressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
  completedExercises: [{
    type: String, // could be exercise IDs or names
  }],
});

module.exports = mongoose.model('Progress', progressSchema);
