const mongoose = require("mongoose");
const validator = require("validator");

const ProgressSchema = new mongoose.Schema({
  date: { type: Date, default: Date.now },
  waterIntake: { type: Number, default: 0 }, // in ml
  caloriesBurned: { type: Number, default: 0 }
});

const LoginSessionSchema = new mongoose.Schema({
  loginTime: { type: Date, default: Date.now },
  logoutTime: { type: Date }
});

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, "Username is required"],
    trim: true,
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    lowercase: true,
    validate: [validator.isEmail, "Invalid email format"],
  },
  password: {
    type: String,
    required: [true, "Password is required"],
    minlength: [6, "Password must be at least 6 characters"],
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  isLoggedIn: { type: Boolean, default: false },

  weight: {
    type: Number, // in kg
    default: 0,
  },
  loginHistory: [LoginSessionSchema],
  progress: [ProgressSchema],
});

// Adding instance method to calculate progress
UserSchema.methods.addProgress = function (waterIntake, caloriesBurned) {
  const progress = {
    date: new Date(),
    waterIntake,
    caloriesBurned
  };

  this.progress.push(progress);
  return this.save();
};

// Adding instance method to start a new login session
UserSchema.methods.startLoginSession = function () {
  const loginSession = {
    loginTime: new Date(),
  };

  this.loginHistory.push(loginSession);
  return this.save();
};

// Adding instance method to end a login session
UserSchema.methods.endLoginSession = function () {
  const lastSession = this.loginHistory[this.loginHistory.length - 1];
  if (lastSession && !lastSession.logoutTime) {
    lastSession.logoutTime = new Date();
    return this.save();
  }
  return Promise.reject("No active session to end.");
};

module.exports = mongoose.model("User", UserSchema);
