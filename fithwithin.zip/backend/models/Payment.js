const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  plan: { type: String, enum: ['Cardio', 'Muscle Gain', 'Weight Loss'], required: true },
  amount: { type: Number, required: true },
  currency: { type: String, default: 'PKR' },
  paymentIntentId: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Payment', paymentSchema);
