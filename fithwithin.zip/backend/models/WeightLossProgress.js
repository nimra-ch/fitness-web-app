const mongoose = require('mongoose');

const weightLossProgressSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  completedDays: [
    {
      week: Number,
      day: String,
    },
  ],
});

module.exports = mongoose.model('WeightLossProgress', weightLossProgressSchema);
