const PersonalInfo = require('../models/PersonalInfo');
const Goal = require('../models/Goal'); // Make sure this import exists

const savePersonalInfo = async (req, res) => {
  const { userId, gender, age, weight, height, goal } = req.body;

  try {
    // Validate required fields
    if (!userId || !gender || !age || !weight || !height || !goal) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // ✅ Calculate BMI safely
    let bmi = null;
    if (weight && height && height > 0) {
      const heightInMeters = height / 100;
      bmi = weight / (heightInMeters * heightInMeters);
    } else {
      return res.status(400).json({ message: "Invalid weight or height. Both must be non-zero numbers." });
    }

    // ✅ Determine BMI classification
    let classification = '';
    if (bmi < 18.5) classification = 'Underweight';
    else if (bmi < 25) classification = 'Normal weight';
    else if (bmi < 30) classification = 'Overweight';
    else classification = 'Obese';

    // ✅ Goal-based warning
    if ((classification === 'Overweight' || classification === 'Obese') && goal === 'weight gain') {
      return res.status(400).json({
        warning: `You're already ${classification.toLowerCase()}. Please consider weight loss exercises.`,
        suggestedPlan: 'weight loss',
      });
    }

    // ✅ Prepare personal info to save
    const dataToSave = {
      userId,
      gender,
      age,
      weight,
      height,
      goal,
      bmi: Number(bmi.toFixed(2)),
      classification,
    };

    // ✅ Save or update personal info
    const existingInfo = await PersonalInfo.findOne({ userId });

    if (existingInfo) {
      await PersonalInfo.updateOne({ userId }, dataToSave);
    } else {
      const newInfo = new PersonalInfo(dataToSave);
      await newInfo.save();
    }

    // ✅ Save goal separately if not already saved
    const existingGoal = await Goal.findOne({ userId });
    if (!existingGoal) {
      await Goal.create({
        userId,
        goalType: goal,
      });
    }

    // ✅ Final response
    res.status(200).json({
      message: "Personal info saved successfully.",
      bmi: Number(bmi.toFixed(2)),
      classification,
    });

  } catch (error) {
    console.error("Error saving personal info:", error);
    res.status(500).json({ message: "Server error", error });
  }
};

module.exports = { savePersonalInfo };
