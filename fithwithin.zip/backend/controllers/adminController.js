// controllers/adminController.js

const User = require('../models/User');
const CardioProgress = require('../models/CardioProgress');
const MuscleProgress = require('../models/MuscleProgress');
const WeightLossProgress = require('../models/WeightLossProgress');
const YogaProgress = require('../models/YogaProgress')

// Hardcoded admin credentials (better to use environment variables)
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'adminpassword';

// Admin Login
exports.adminLogin = async (req, res) => {
  const { email, password } = req.body;

  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    return res.status(200).json({ message: 'Login successful' });
  } else {
    return res.status(401).json({ message: 'Invalid admin credentials' });
  }
};

// Fetch all users
// Updated getAllUsers to support both direct call and internal call
exports.getAllUsers = async (req, res, returnData = false) => {
  try {
    const users = await User.find().select('-password');

    if (returnData) {
      return users; // If used internally, return data directly
    }

    return res.status(200).json(users); // If used as route handler
  } catch (err) {
    if (returnData) {
      throw new Error(err.message); // Propagate error if internal
    }

    return res.status(500).json({ message: 'Error fetching users', error: err.message });
  }
};


// Get user by ID
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });

    return res.status(200).json(user);
  } catch (err) {
    return res.status(500).json({ message: 'Error fetching user', error: err.message });
  }
};

// Delete user by ID
exports.deleteUser = async (req, res) => {
  try {
    const deletedUser = await User.findByIdAndDelete(req.params.id);
    if (!deletedUser) return res.status(404).json({ message: 'User not found' });

    return res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Error deleting user', error: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;

    // Find and update the user
    const updatedUser = await User.findByIdAndUpdate(id, req.body, {
      new: true,              // Return the updated document
      runValidators: true     // Run schema validations
    });

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({
      message: 'User updated successfully',
      user: updatedUser
    });
  } catch (err) {
    return res.status(500).json({
      message: 'Error updating user',
      error: err.message
    });
  }
};


// Get all logged-in users (users with at least one login)
exports.getLoggedInUsers = async (req, res) => {
  try {
    const users = await User.find({ 'loginHistory.loginTime': { $exists: true, $ne: null } })
      .select('username email goal loginHistory');

    return res.status(200).json(users);
  } catch (err) {
    return res.status(500).json({ message: 'Error fetching logged-in users', error: err.message });
  }
};

// Generate a weekly activity report
exports.getWeeklyReport = async (req, res) => {
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

  try {
    const users = await User.find({ createdAt: { $gte: oneWeekAgo } })
      .select('username email goal progress loginHistory createdAt');

    const report = users.map(user => {
      const lastLogin = user.loginHistory?.slice(-1)[0]?.loginTime || null;
      const lastLogout = user.loginHistory?.slice(-1)[0]?.logoutTime || null;

      return {
        username: user.username,
        email: user.email,
        goal: user.goal,
        progress: user.progress,
        lastLogin,
        lastLogout,
        createdAt: user.createdAt
      };
    });

    return res.status(200).json(report);
  } catch (err) {
    console.error('Error generating weekly report:', err);
    return res.status(500).json({ message: 'Failed to generate report', error: err.message });
  }
};

exports.getCountofAllServices = async (req, res,returnData=false) => {
  try {
    const yogaCount = await YogaProgress.count();
    const weightCount = await WeightLossProgress.count();
    const cardioCount = await CardioProgress.count();
    const muscleCount = await MuscleProgress.count();

    const result = [
      { name: 'Yoga', value: yogaCount },
      { name: 'Cardio', value: cardioCount },
      { name: 'Muscle Gain', value: muscleCount },
      { name: 'Weight Loss', value: weightCount },
    ];

    if(returnData){
      return result;
    }
    return res.status(200).json({
      success: true,
      data: result,
    });

  } catch (error) {
    console.error('Error fetching service counts:', error);

    return res.status(500).json({
      success: false,
      message: 'Failed to fetch service counts.',
      error: error.message || 'Internal Server Error',
    });
  }
};



exports.getUserStatistics = async (req, res, returnData=false) => {
  try {
    const now = new Date();

    // Start of current month
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Start of today
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // 1. Count of all users
    const totalUsers = await User.countDocuments();

    // 2. Count of users created in the current month
    const usersThisMonth = await User.countDocuments({ createdAt: { $gte: startOfMonth } });

    // 3. Count of users who have loginHistory with loginTime today
    const activeUsersToday = await User.countDocuments({
      loginHistory: {
        $elemMatch: {
          loginTime: { $gte: startOfToday }
        }
      }
    });

    if(returnData){
      return {
        totalUsers,
        newUsersThisMonth: usersThisMonth,
        activeUsersToday
      };
    }

    return res.status(200).json({
      success: true,
      data: {
        totalUsers,
        newUsersThisMonth: usersThisMonth,
        activeUsersToday
      }
    });

  } catch (error) {
    console.error("Error fetching user statistics:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to retrieve user statistics",
      error: error.message
    });
  }
};


exports.finalApiOfAdminPanel = async (req, res) => {
  try {
    const getAllUsers = await this.getAllUsers(null,null,true);
    const statistics = await this.getUserStatistics(null,null,true);
    const counts = await this.getCountofAllServices(null,null,true);

    return res.status(200).json({
      success: true,
      message: "Admin dashboard data fetched successfully",
      data: {
        users: getAllUsers,
        statistics,
        serviceCounts: counts,
      },
    });
  } catch (error) {
    console.error("Error in finalApiOfAdminPanel:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch admin dashboard data",
      error: error.message || "Internal server error",
    });
  }
};
