const Goal = require('../models/Goal');
const User = require('../models/User');

// Set goal
exports.setGoal = async (req, res) => {
  const { goalType } = req.body;
  const userId = req.user.id;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    // Restriction: Already overweight for Muscle Gain
    if (user.weight > 90 && goalType === "Muscle Gain") {
      return res.status(400).json({ message: "You are already overweight. Choose a different goal." });
    }

    // Remove previous goal if only one goal is allowed
    await Goal.deleteMany({ userId });

    // Create a new goal
    const newGoal = new Goal({
      userId,
      goalType
    });

    await newGoal.save();

    res.status(201).json({ message: "Goal set successfully", goal: newGoal });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error", error });
  }
};

// Get goal
exports.getGoal = async (req, res) => {
  try {
    const goal = await Goal.findOne({ userId: req.user.id }).sort({ createdAt: -1 });
    if (!goal) return res.status(404).json({ message: "No goal found" });

    res.json({ goal });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Update goal
exports.updateGoal = async (req, res) => {
  const { goalType } = req.body;
  const userId = req.user.id;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user.weight > 90 && goalType === "Muscle Gain") {
      return res.status(400).json({ message: "You are already overweight. Choose a different goal." });
    }

    const goal = await Goal.findOneAndUpdate(
      { userId },
      { goalType },
      { new: true, upsert: true }
    );

    res.json({ message: "Goal updated successfully", goal });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Delete goal
exports.deleteGoal = async (req, res) => {
  try {
    await Goal.deleteMany({ userId: req.user.id });
    res.json({ message: "Goal deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};
