const User = require("../models/User");

exports.updateProgress = async (req, res) => {
  const { waterIntake, caloriesBurned } = req.body;
  const userId = req.user.id;

  try {
    const user = await User.findById(userId);
    const today = new Date().toISOString().split("T")[0];

    let todayProgress = user.progress.find(p => new Date(p.date).toISOString().split("T")[0] === today);

    if (todayProgress) {
      todayProgress.waterIntake += waterIntake;
      todayProgress.caloriesBurned += caloriesBurned;
    } else {
      user.progress.push({ waterIntake, caloriesBurned });
    }

    await user.save();
    res.json({ message: "Progress updated" });
  } catch (err) {
    res.status(500).json({ message: "Error updating progress" });
  }
};
