// server.js

const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const seedYogaPlansIfNeeded = require('./utils/scripts/seedYoga');
const seedCardioPlansIfNeeded = require('./utils/scripts/seedCardio');
const seedMusclePlansIfNeeded = require('./utils/scripts/seedMuscle');
const seedWeightLossPlansIfNeeded = require('./utils/scripts/seedWeightLoss');
const bcrypt = require('bcryptjs');
const cookieParser = require('cookie-parser');

// Load environment variables
dotenv.config();

// Import models
const Admin = require('./models/adminModel');

// Import routes
const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const personalInfoRoutes = require('./routes/personal');
const adminRoutes = require('./routes/adminRoutes');
const goalRoutes = require('./routes/goalRoutes');
const yogaRoutes = require('./routes/yoga');
const personalRoutes = require('./routes/personal');
const muscleRoutes = require('./routes/muscle');
const weightLossRoutes = require('./routes/weightloss');
const cardioRoutes = require('./routes/cardio');
const paymentRoutes = require('./routes/payments');

// Initialize Express App
const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());

// CORS Configuration
app.use(
  cors({
    origin: 'http://localhost:5173',
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
  })
);

// API Routes
app.use('/api/users', userRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/info', personalInfoRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/goals', goalRoutes);
app.use('/api/services/yoga', yogaRoutes);
app.use('/api/services/cardio', cardioRoutes);
app.use('/api/services/muscle', muscleRoutes);
app.use('/api/services/weightloss', weightLossRoutes);
app.use('/api/personal', personalRoutes);
app.use('/api/payments', paymentRoutes);

// Connect to Database & Ensure Admin Exists
const startServer = async () => {
  try {
    await connectDB();
    console.log('MongoDB Connected');

    // Ensure admin user is created
    await createAdmin();
    await seedYogaPlansIfNeeded();
    await seedCardioPlansIfNeeded();
    await seedMusclePlansIfNeeded();
    await seedWeightLossPlansIfNeeded();
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  } catch (err) {
    console.error('Server Startup Error:', err);
    process.exit(1);
  }
};

// Ensure an Admin Exists
const createAdmin = async () => {
  try {
    const adminEmail = 'noreen@gmail.com';
    const adminPassword = '1234567890';

    const existingAdmin = await Admin.findOne({ email: adminEmail });

    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash(adminPassword, 10);
      const admin = new Admin({
        email: adminEmail,
        password: hashedPassword,
      });

      await admin.save();
      console.log('Admin account created successfully!');
    } else {
      console.log('Admin already exists.');
    }
  } catch (error) {
    console.error('Error creating admin:', error);
  }
};

// Start the Server
startServer();
