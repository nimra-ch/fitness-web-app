// middleware/authMiddleware.js
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Protect routes that require authentication
const protect = async (req, res, next) => {
  let token;
  
  // Check for the presence of the token in the Authorization header
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      // Extract token from header
      token = req.headers.authorization.split(" ")[1];
      
      // Decode the token to get the user ID
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Find the user based on the decoded ID and exclude the password field for security
      req.user = await User.findById(decoded.id).select("-password");
      
      // Proceed to the next middleware or route handler
      next();
    } catch (error) {
      console.error("Auth failed:", error);
      res.status(401).json({ error: "Not authorized, token failed" });
    }
  } else {
    res.status(401).json({ error: "Not authorized, no token" });
  }
};

module.exports = { protect };
