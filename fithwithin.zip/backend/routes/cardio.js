const express = require('express');
const CardioPlan = require('../models/CardioPlan');
const CardioProgress = require('../models/CardioProgress');

const router = express.Router();

// GET: All 4-week cardio plan
router.get('/', async (req, res) => {
  const plans = await CardioPlan.find().sort({ week: 1 });
  res.json(plans);
});

// POST: Mark a day complete
router.post('/complete/:userId', async (req, res) => {
  const { userId } = req.params;
  const { week, day } = req.body;

  if (!week || !day) {
    return res.status(400).json({ message: 'Week and day are required' });
  }

  let progress = await CardioProgress.findOne({ userId });

  if (!progress) {
    progress = await CardioProgress.create({ userId, completedDays: [{ week, day }] });
  } else {
    const already = progress.completedDays.find(
      (entry) => entry.week === week && entry.day === day
    );
    if (already) {
      return res.status(400).json({ message: 'Already marked completed' });
    }

    progress.completedDays.push({ week, day });
    await progress.save();
  }

  res.json({ message: 'Workout marked as completed', progress });
});

// GET: Progress of user
router.get('/:userId/progress', async (req, res) => {
  const { userId } = req.params;
  const progress = await CardioProgress.findOne({ userId });
  res.json(progress || { completedDays: [] });
});


module.exports = router;