const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');  // Middleware to protect routes

// Importing methods from the controller
const {
  adminLogin,
  getAllUsers,
  getUserById,
  deleteUser,
  getLoggedInUsers,
  getWeeklyReport,
  finalApiOfAdminPanel,
  updateUser,
} = require('../controllers/adminController');

// Public: Admin login
router.post('/login', adminLogin);

// Protected: All routes below require admin auth
// router.use(protect);

// User management
router.get('/users', getAllUsers);  // Get all users
router.get('/users/:id', getUserById);  // Get a user by ID
router.delete('/users/:id', deleteUser);  // Delete a user by ID
router.put('/users-update/:id', updateUser);  // Delete a user by ID

// Logged-in users
router.get('/logged-in-users', getLoggedInUsers);  // Get all logged-in users

// Weekly report
router.get('/weekly-report', getWeeklyReport);  // Generate weekly report


router.get('/dashboard', finalApiOfAdminPanel)

module.exports = router;
