const express = require('express');
const stripe = require('stripe')('sk_test_51RlPHJIwg4sujJFrBt4JEz0WNDTvYW2VZIRQ7naQ6MoEC9MJMkyQqM3ivaX68hW5CtPZObfUkQdyDQggbLPBtHqe00tPaXoYth'); // Replace with your actual Stripe secret key
const Payment = require('../models/Payment');
const Trial = require('../models/Trial');

const router = express.Router();

// POST /api/payments/create-intent
router.post('/create-intent', async (req, res) => {
  const { userId, plan, amount } = req.body;

  if (!userId || !plan || !amount) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // convert to smallest currency unit
      currency: 'pkr',
      metadata: { userId, plan },
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    console.error('Stripe Error:', err.message);
    res.status(500).json({ message: 'Failed to create payment intent' });
  }
});

// POST /api/payments/confirm
router.post('/confirm', async (req, res) => {
  const { userId, plan, amount, paymentIntentId } = req.body;

  try {
    const existing = await Payment.findOne({ paymentIntentId });
    if (existing) {
      return res.status(400).json({ message: 'Payment already recorded' });
    }

    const payment = await Payment.create({
      userId,
      plan,
      amount,
      paymentIntentId
    });

    res.json({ message: 'Payment confirmed', payment });
  } catch (err) {
    console.error('Save Error:', err.message);
    res.status(500).json({ message: 'Failed to save payment' });
  }
});

// POST /api/payments/start-trial
router.post('/start-trial', async (req, res) => {
  const { userId } = req.body;

  try {
    const existing = await Trial.findOne({ userId });
    if (existing) {
      return res.status(400).json({ message: 'Trial already used' });
    }

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000); // 14 days later

    const trial = await Trial.create({
      userId,
      startedAt: now,
      expiresAt,
    });

    res.json({ message: 'Trial started', trial });
  } catch (err) {
    console.error('Trial Error:', err.message);
    res.status(500).json({ message: 'Failed to start trial' });
  }
});

// GET /api/payments/trial-status/:userId
router.get('/trial-status/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const trial = await Trial.findOne({ userId });

    if (!trial) {
      return res.json({ active: false, message: 'No trial found' });
    }

    const now = new Date();
    const active = trial.expiresAt > now;

    res.json({ active, expiresAt: trial.expiresAt });
  } catch (err) {
    res.status(500).json({ message: 'Failed to check trial status' });
  }
});

module.exports = router;
