const express = require('express');
const { loginUser, logoutUser } = require('../controllers/authController');
const router = express.Router();

// POST /api/auth/login
router.post('/login', loginUser);

// POST /api/auth/logout
router.post('/logout', logoutUser);

module.exports = router;
