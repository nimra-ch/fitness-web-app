const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
require("dotenv").config();

// Admin Login Route
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  // Check if email and password match the stored admin credentials
  if (email !== process.env.ADMIN_EMAIL) {
    return res.status(401).json({ error: "Invalid email" });
  }

  // Compare passwords (hashed for security)
  const isPasswordValid = await bcrypt.compare(password, await bcrypt.hash(process.env.ADMIN_PASSWORD, 10));

  if (!isPasswordValid) {
    return res.status(401).json({ error: "Invalid password" });
  }

  // Generate JWT Token
  const token = jwt.sign({ role: "admin" }, process.env.JWT_SECRET, { expiresIn: "2h" });

  res.json({ message: "Login successful", token });
});

module.exports = router;
