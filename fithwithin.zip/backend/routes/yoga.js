const express = require('express');
const YogaPlan = require('../models/YogaPlan');
const YogaProgress = require('../models/YogaProgress');

const router = express.Router();

// GET all yoga plans
router.get('/', async (req, res) => {
  try {
    const plans = await YogaPlan.find();
    res.json(plans);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// POST: Select yoga level
router.post('/select/:userId', async (req, res) => {
  const { userId } = req.params;
  const { level } = req.body;

  try {
    const plan = await YogaPlan.findOne({ level });
    if (!plan) {
      return res.status(404).json({ message: 'Invalid yoga level.' });
    }

    let progress = await YogaProgress.findOne({ userId });

    if (progress) {
      if(progress.selectedLevel === level){
        return res.json({ message: 'Yoga level selected/updated successfully.', progress });
      }
      // Update selectedLevel and clear completedWorkouts
      progress.selectedLevel = level;
      progress.completedWorkouts = [];
      await progress.save();
    } else {
      // Create new progress
      progress = await YogaProgress.create({
        userId,
        selectedLevel: level,
        completedWorkouts: [],
      });
    }

    res.json({ message: 'Yoga level selected/updated successfully.', progress });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

router.post('/reset/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const progress = await YogaProgress.findOne({ userId });
    if (!progress) {
      return res.status(404).json({ message: 'Progress not found.' });
    }

    progress.selectedLevel = null;
    progress.completedWorkouts = [];
    await progress.save();

    res.json({ message: 'Progress reset successfully.' });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});


// POST /api/services/yoga/:userId/progress
router.post('/complete/:userId', async (req, res) => {
  const { userId } = req.params;
  const { workoutTitle } = req.body;

  if (!workoutTitle) {
    return res.status(400).json({ message: 'Workout title is required' });
  }

  try {
    const progress = await YogaProgress.findOne({ userId });

    if (!progress) {
      return res.status(404).json({ message: 'Yoga plan not selected yet' });
    }

    if (progress.completedWorkouts.includes(workoutTitle)) {
      return res.status(400).json({ message: 'Workout already completed' });
    }

    progress.completedWorkouts.push(workoutTitle);
    await progress.save();

    res.json({ message: 'Workout marked as completed', progress });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});


// GET /api/services/yoga/:userId/progress
router.get('/get-progress/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const progress = await YogaProgress.findOne({ userId });

    if (!progress) {
      return res.status(404).json({ message: 'No yoga progress found' });
    }

    res.json(progress);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});


module.exports = router;
