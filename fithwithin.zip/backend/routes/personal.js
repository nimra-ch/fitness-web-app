// const express = require('express');
// const router = express.Router();
// const PersonalInfo = require('../models/PersonalInfo');
// const Trial = require('../models/Trial');

// function calculateBMI(weight, height) {
//   const heightInMeters = height / 100;
//   return weight / (heightInMeters * heightInMeters);
// }

// function classifyBMI(bmi) {
//   if (bmi < 18.5) return 'Underweight';
//   if (bmi < 25) return 'Normal';
//   if (bmi < 30) return 'Overweight';
//   return 'Obese';
// }

// // POST: Save personal info and start trial
// router.post('/', async (req, res) => {
//   const { userId, gender, age, weight, height, goal } = req.body;

//   if (!userId || !gender || !age || !weight || !height || !goal) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

//   const bmi = calculateBMI(weight, height);
//   const classification = classifyBMI(bmi);

//   // Restrict underweight users from selecting Weight Loss
//   if (goal === 'Weight Loss' && classification === 'Underweight') {
//     return res.status(400).json({ message: 'You are underweight. Weight Loss is not recommended.' });
//   }

//   try {
//     let info = await PersonalInfo.findOne({ userId });

//     if (info) {
//       info.gender = gender;
//       info.age = age;
//       info.weight = weight;
//       info.height = height;
//       info.goal = goal;
//       info.bmi = bmi;
//       info.classification = classification;
//       await info.save();
//     } else {
//       info = await PersonalInfo.create({
//         userId,
//         gender,
//         age,
//         weight,
//         height,
//         goal,
//         bmi,
//         classification,
//       });

//       // Create trial (14 days)
//       const expiresAt = new Date();
//       expiresAt.setDate(expiresAt.getDate() + 14);
//       await Trial.create({ userId, expiresAt });
//     }

//     res.status(200).json({
//       message: 'Personal info saved successfully',
//       bmi,
//       classification,
//       trialEnds: info.createdAt ? null : expiresAt,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: 'Server error' });
//   }
// });

// // GET: Trial status
// router.get('/:userId/trial-status', async (req, res) => {
//   const { userId } = req.params;

//   try {
//     const trial = await Trial.findOne({ userId });

//     if (!trial) return res.status(404).json({ message: 'No trial found' });

//     const now = new Date();
//     const isActive = now <= trial.expiresAt;

//     res.json({ active: isActive, expiresAt: trial.expiresAt });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error' });
//   }
// });


// module.exports = router;

const express = require('express');
const router = express.Router();
const PersonalInfo = require('../models/PersonalInfo');
const Trial = require('../models/Trial');
const Payment = require('../models/Payment'); // NEW

function calculateBMI(weight, height) {
  const heightInMeters = height / 100;
  return weight / (heightInMeters * heightInMeters);
}

function classifyBMI(bmi) {
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

// POST: Save personal info, optionally start trial
router.post('/', async (req, res) => {
  const { userId, gender, age, weight, height, goal } = req.body;

  if (!userId || !gender || !age || !weight || !height || !goal) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const bmi = calculateBMI(weight, height);
  const classification = classifyBMI(bmi);

  if (goal === 'Weight Loss' && classification === 'Underweight') {
    return res.status(400).json({
      message: 'You are underweight. Weight Loss is not recommended.'
    });
  }

  try {
    // Check if payment already exists (skip trial if paid)
    const paid = await Payment.findOne({ userId });

    let trial = await Trial.findOne({ userId });

    // Save or update personal info
    let info = await PersonalInfo.findOne({ userId });
    if (info) {
      Object.assign(info, { gender, age, weight, height, goal, bmi, classification });
      await info.save();
    } else {
      info = await PersonalInfo.create({
        userId, gender, age, weight, height, goal, bmi, classification
      });
    }

    let trialEnds = null;

    // If not paid, and no previous trial → start one
    if (!paid && !trial) {
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000); // 14 days
      trial = await Trial.create({ userId, startedAt: now, expiresAt });
      trialEnds = expiresAt;
    } else if (trial) {
      trialEnds = trial.expiresAt;
    }

    res.status(200).json({
      message: 'Personal info saved successfully',
      bmi,
      classification,
      trialEnds
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET: Fetch personal info for a user
router.get('/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const info = await PersonalInfo.findOne({ userId });

    if (!info) {
      return res.status(404).json({ message: 'No personal info found for this user' });
    }

    res.status(200).json({
      gender: info.gender,
      age: info.age,
      weight: info.weight,
      height: info.height, // in cm
      goal: info.goal,
      bmi: info.bmi,
      classification: info.classification,
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});


module.exports = router;
