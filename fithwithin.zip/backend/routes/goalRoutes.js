const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const Goal = require('../models/Goal');

router.post('/', protect, async (req, res) => {
  try {
    const { goal } = req.body;

    if (!goal) {
      return res.status(400).json({ error: 'Goal is required' });
    }

    const newGoal = new Goal({
      userId: req.user._id,
      goalType: goal,
    });

    await newGoal.save();

    res.status(200).json({ message: 'Goal saved successfully', goal: newGoal });
  } catch (error) {
    console.error('Goal save error:', error.message);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
