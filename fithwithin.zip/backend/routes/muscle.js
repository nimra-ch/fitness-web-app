const express = require('express');
const MusclePlan = require('../models/MusclePlan');
const MuscleProgress = require('../models/MuscleProgress');

const router = express.Router();

// Get full muscle gain plan
router.get('/', async (req, res) => {
  const plans = await MusclePlan.find().sort({ week: 1 });
  res.json(plans);
});

// Mark workout complete
router.post('/complete/:userId', async (req, res) => {
  const { userId } = req.params;
  const { week, day } = req.body;

  if (!week || !day) {
    return res.status(400).json({ message: 'Week and day required' });
  }

  let progress = await MuscleProgress.findOne({ userId });

  if (!progress) {
    progress = await MuscleProgress.create({ userId, completedDays: [{ week, day }] });
  } else {
    const already = progress.completedDays.find(
      (entry) => entry.week === week && entry.day === day
    );
    if (already) {
      return res.status(400).json({ message: 'Already marked complete' });
    }

    progress.completedDays.push({ week, day });
    await progress.save();
  }

  res.json({ message: 'Marked complete', progress });
});

// Get progress
router.get('/:userId/progress', async (req, res) => {
  const { userId } = req.params;
  const progress = await MuscleProgress.findOne({ userId });
  res.json(progress || { completedDays: [] });
});


module.exports = router;