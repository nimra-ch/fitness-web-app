const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { loginUser, logoutUser } = require('../controllers/authController');
const { setGoal } = require('../controllers/goalController');
const { updateProgress } = require('../controllers/progressController');
const { protect } = require('../middleware/auth');
const { verifyEmail } = require('../controllers/verifyController');
const { sendWelcomeEmail } = require('../utils/emails/emailSender');
const { sendLogoutEmail } = require('../utils/emails/logoutEmailSender');

router.post('/signup', async (req, res) => {
  try {
    let { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    email = email.trim().toLowerCase();
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already in use' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword, isVerified: false });
    await newUser.save();

    const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: '60d' });
    const verificationLink = `http://localhost:5173/verified?token=${token}`;
    console.log('Verification link:', verificationLink);
    await sendWelcomeEmail({
      username: newUser.username,
      email: newUser.email,
      verificationLink
    });
    res.status(201).json({
      message: 'User registered. Please check console for verification link.',
      userId: newUser._id,
    });
  } catch (error) {
    console.error('Signup Error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/verify/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId;

    const user = await User.findByIdAndUpdate(userId, { isVerified: true }, { new: true });
    if (!user) return res.status(404).json({ message: 'User not found' });

    res.json({ message: 'Email verified. You can now log in.' });
  } catch (error) {
    console.error('Verification Error:', error);
    res.status(400).json({ error: 'Invalid or expired verification link' });
  }
});
router.get('/verify/:token', verifyEmail);
router.post('/login', loginUser);
// router.post('/logout', protect, logoutUser);
router.post('/set-goal', protect, setGoal);
router.post('/update-progress', protect, updateProgress);



router.post('/logout', async (req, res) => {
  try {
    const { userId } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    await sendLogoutEmail({
      username: user.username,
      email: user.email
    });

    // Perform any logout logic if needed (e.g., token invalidation)
    res.status(200).json({ message: 'User logged out and email sent' });
  } catch (error) {
    console.error('Logout Error:', error);
    res.status(500).json({ error: 'Server error during logout' });
  }
});


module.exports = router;