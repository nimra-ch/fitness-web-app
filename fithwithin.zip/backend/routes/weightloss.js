const express = require('express');
const WeightLossPlan = require('../models/WeightLossPlan');
const WeightLossProgress = require('../models/WeightLossProgress');

const router = express.Router();

// Get all weeks of plan
router.get('/', async (req, res) => {
  const plans = await WeightLossPlan.find().sort({ week: 1 });
  res.json(plans);
});

// Mark a workout complete
router.post('/complete/:userId', async (req, res) => {
  const { userId } = req.params;
  const { week, day } = req.body;

  if (!week || !day) {
    return res.status(400).json({ message: 'Week and day are required' });
  }

  let progress = await WeightLossProgress.findOne({ userId });

  if (!progress) {
    progress = await WeightLossProgress.create({ userId, completedDays: [{ week, day }] });
  } else {
    const already = progress.completedDays.find(
      (entry) => entry.week === week && entry.day === day
    );
    if (already) {
      return res.status(400).json({ message: 'Already marked complete' });
    }

    progress.completedDays.push({ week, day });
    await progress.save();
  }

  res.json({ message: 'Marked complete', progress });
});

// Get progress of a user
router.get('/:userId/progress', async (req, res) => {
  const { userId } = req.params;
  const progress = await WeightLossProgress.findOne({ userId });
  res.json(progress || { completedDays: [] });
});


module.exports = router;