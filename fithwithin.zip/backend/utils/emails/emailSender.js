// server/emails/emailSender.js
const nodemailer = require('nodemailer');
const hbs = require('handlebars');
const fs = require('fs');
const path = require('path');

const sendWelcomeEmail = async ({ username, email, verificationLink }) => {
  const source = fs.readFileSync(
    path.join(__dirname, 'welcomeTemplate.hbs'),
    'utf-8'
  );
  const template = hbs.compile(source);
  const html = template({ username, verificationLink });

  const transporter = nodemailer.createTransport({
    service: 'Gmail', // or your SMTP service
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  await transporter.sendMail({
    from: `"Fitwithin" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Welcome to Fitwithin - Verify Your Email',
    html
  });
};

module.exports = { sendWelcomeEmail };
