// server/emails/emailSender.js
const nodemailer = require('nodemailer');
const hbs = require('handlebars');
const fs = require('fs');
const path = require('path');

const sendLogoutEmail = async ({ username, email }) => {
  const source = fs.readFileSync(
    path.join(__dirname, 'logoutTemplate.hbs'),
    'utf-8'
  );
  const template = hbs.compile(source);
  const html = template({ username });

  const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  await transporter.sendMail({
    from: `"Fitwithin" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'You have logged out of Fitwithin',
    html
  });
};

module.exports = {
  sendLogoutEmail
};
