const YogaPlan = require('../../models/YogaPlan');

const seedYogaPlansIfNeeded = async () => {
  const count = await YogaPlan.countDocuments();

  if (count === 0) {
    await YogaPlan.insertMany([
      {
        level: 'Beginner',
        workouts: ['Morning Flow', 'Hatha Yoga', 'Restorative Yoga', 'Chair Yoga'],
      },
      {
        level: 'Intermediate',
        workouts: ['Vinyasa Flow', 'Yin Yoga', 'Flow & Restore', 'Ashtanga Modified'],
      },
      {
        level: 'Advanced',
        workouts: ['Power Yoga', 'Advanced Yoga', 'Ashtanga Full', 'Inversions Flow'],
      },
    ]);
    console.log('✅ Yoga Plans auto-seeded');
  } else {
    console.log('ℹ️ Yoga Plans already exist');
  }
};

module.exports = seedYogaPlansIfNeeded;
