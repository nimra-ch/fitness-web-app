const CardioPlan = require('../../models/CardioPlan');

const weeks = [
  {
    week: 1,
    schedule: [
      { day: 'Monday', activity: 'HIIT Cardio - 30 min', intensity: 'Moderate' },
      { day: 'Tuesday', activity: 'Running Intervals - 25 min', intensity: 'High' },
      { day: 'Wednesday', activity: 'Active Recovery/Stretching', intensity: 'Low' },
      { day: 'Thursday', activity: 'Cycling - 40 min', intensity: 'Moderate' },
      { day: 'Friday', activity: 'Swimming - 30 min', intensity: 'Moderate' },
      { day: 'Saturday', activity: 'Long Run - 45 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 2,
    schedule: [
      { day: 'Monday', activity: 'Sprint Intervals - 25 min', intensity: 'High' },
      { day: 'Tuesday', activity: 'Cycling Hills - 35 min', intensity: 'High' },
      { day: 'Wednesday', activity: 'Yoga/Stretching', intensity: 'Low' },
      { day: 'Thursday', activity: 'HIIT Training - 30 min', intensity: 'High' },
      { day: 'Friday', activity: 'Steady State Cardio - 45 min', intensity: 'Moderate' },
      { day: 'Saturday', activity: 'Mixed Cardio - 40 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 3,
    schedule: [
      { day: 'Monday', activity: 'Tempo Run - 35 min', intensity: 'High' },
      { day: 'Tuesday', activity: 'Swimming Intervals - 30 min', intensity: 'High' },
      { day: 'Wednesday', activity: 'Light Jogging - 20 min', intensity: 'Low' },
      { day: 'Thursday', activity: 'Boxing Cardio - 30 min', intensity: 'High' },
      { day: 'Friday', activity: 'Cycling - 45 min', intensity: 'Moderate' },
      { day: 'Saturday', activity: 'Trail Run - 40 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 4,
    schedule: [
      { day: 'Monday', activity: 'HIIT Pyramid - 35 min', intensity: 'High' },
      { day: 'Tuesday', activity: 'Endurance Run - 45 min', intensity: 'Moderate' },
      { day: 'Wednesday', activity: 'Recovery Walk - 30 min', intensity: 'Low' },
      { day: 'Thursday', activity: 'Mixed Intervals - 30 min', intensity: 'High' },
      { day: 'Friday', activity: 'Stair Climber - 30 min', intensity: 'High' },
      { day: 'Saturday', activity: 'Long Distance - 50 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
];

const seedCardioPlansIfNeeded = async () => {
  const count = await CardioPlan.countDocuments();
  if (count === 0) {
    await CardioPlan.insertMany(weeks);
    console.log('✅ Cardio Plans Seeded');
  } else {
    console.log('ℹ️ Cardio Plans already exist');
  }
};

module.exports = seedCardioPlansIfNeeded;
