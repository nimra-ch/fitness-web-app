const MusclePlan = require('../../models/MusclePlan');

const weeks = [
  {
    week: 1,
    schedule: [
      { day: 'Monday', activity: 'Upper Body Strength Training (Chest, Shoulders, Triceps)', intensity: 'High' },
      { day: 'Tuesday', activity: 'Lower Body Strength Training (Squats, Deadlifts)', intensity: 'High' },
      { day: 'Wednesday', activity: 'Rest or Active Recovery (Light Cardio/Stretching)', intensity: 'Low' },
      { day: 'Thursday', activity: 'Back and Biceps Strength Training', intensity: 'High' },
      { day: 'Friday', activity: 'Legs and Core Workout', intensity: 'High' },
      { day: 'Saturday', activity: 'Full Body Functional Training', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 2,
    schedule: [
      { day: 'Monday', activity: 'Push Day: Chest, Shoulders, Triceps', intensity: 'High' },
      { day: 'Tuesday', activity: 'Pull Day: Back, Biceps', intensity: 'High' },
      { day: 'Wednesday', activity: 'Leg Day: Squats, Lunges', intensity: 'High' },
      { day: 'Thursday', activity: 'Core and Stability Exercises', intensity: 'Moderate' },
      { day: 'Friday', activity: 'Full Body Compound Movements', intensity: 'High' },
      { day: 'Saturday', activity: 'Active Recovery or Yoga', intensity: 'Low' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 3,
    schedule: [
      { day: 'Monday', activity: 'Upper Body Hypertrophy Training', intensity: 'High' },
      { day: 'Tuesday', activity: 'Lower Body Strength Training', intensity: 'High' },
      { day: 'Wednesday', activity: 'Active Recovery (Swimming or Light Cardio)', intensity: 'Low' },
      { day: 'Thursday', activity: 'Back and Core Strength Training', intensity: 'High' },
      { day: 'Friday', activity: 'Legs and Glutes Focused Workout', intensity: 'High' },
      { day: 'Saturday', activity: 'Functional Strength and Conditioning', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 4,
    schedule: [
      { day: 'Monday', activity: 'Push-Pull Hybrid Training', intensity: 'High' },
      { day: 'Tuesday', activity: 'Leg Strength and Power Training', intensity: 'High' },
      { day: 'Wednesday', activity: 'Mobility and Stretching', intensity: 'Low' },
      { day: 'Thursday', activity: 'Upper Body Strength Circuits', intensity: 'High' },
      { day: 'Friday', activity: 'Core and Stability Focus', intensity: 'Moderate' },
      { day: 'Saturday', activity: 'Full Body Conditioning', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
];

const seedMusclePlansIfNeeded = async () => {
  const count = await MusclePlan.countDocuments();
  if (count === 0) {
    await MusclePlan.insertMany(weeks);
    console.log('✅ Muscle Plans Seeded');
  } else {
    console.log('ℹ️ Muscle Plans already exist');
  }
};

module.exports = seedMusclePlansIfNeeded;
