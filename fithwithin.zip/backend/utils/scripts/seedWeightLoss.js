const WeightLossPlan = require('../../models/WeightLossPlan');

const weeks = [
  {
    week: 1,
    schedule: [
      { day: 'Monday', activity: 'Brisk Walking - 30 min', intensity: 'Moderate' },
      { day: 'Tuesday', activity: 'Bodyweight Squats - 20 min', intensity: 'Moderate' },
      { day: 'Wednesday', activity: 'Rest or Light Yoga', intensity: 'Low' },
      { day: 'Thursday', activity: 'Jumping Jacks - 15 min', intensity: 'Moderate' },
      { day: 'Friday', activity: 'Mountain Climbers - 15 min', intensity: 'High' },
      { day: 'Saturday', activity: 'Plank - 10 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 2,
    schedule: [
      { day: 'Monday', activity: 'Brisk Walking - 35 min', intensity: 'Moderate' },
      { day: 'Tuesday', activity: 'Burpees - 20 min', intensity: 'High' },
      { day: 'Wednesday', activity: 'Rest or Light Yoga', intensity: 'Low' },
      { day: 'Thursday', activity: 'Jumping Jacks - 20 min', intensity: 'Moderate' },
      { day: 'Friday', activity: 'Mountain Climbers - 20 min', intensity: 'High' },
      { day: 'Saturday', activity: 'Bodyweight Squats - 25 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 3,
    schedule: [
      { day: 'Monday', activity: 'Jogging - 30 min', intensity: 'Moderate' },
      { day: 'Tuesday', activity: 'Burpees - 25 min', intensity: 'High' },
      { day: 'Wednesday', activity: 'Yoga/Stretching', intensity: 'Low' },
      { day: 'Thursday', activity: 'Mountain Climbers - 25 min', intensity: 'High' },
      { day: 'Friday', activity: 'Jump Rope - 20 min', intensity: 'Moderate' },
      { day: 'Saturday', activity: 'Plank - 15 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
  {
    week: 4,
    schedule: [
      { day: 'Monday', activity: 'Interval Running - 30 min', intensity: 'High' },
      { day: 'Tuesday', activity: 'Bodyweight Squats - 30 min', intensity: 'Moderate' },
      { day: 'Wednesday', activity: 'Recovery Walk - 30 min', intensity: 'Low' },
      { day: 'Thursday', activity: 'Burpees - 30 min', intensity: 'High' },
      { day: 'Friday', activity: 'Mountain Climbers - 30 min', intensity: 'High' },
      { day: 'Saturday', activity: 'Jumping Jacks - 25 min', intensity: 'Moderate' },
      { day: 'Sunday', activity: 'Rest Day', intensity: 'Rest' },
    ],
  },
];

const seedWeightLossPlansIfNeeded = async () => {
  const count = await WeightLossPlan.countDocuments();
  if (count === 0) {
    await WeightLossPlan.insertMany(weeks);
    console.log('✅ Weight Loss Plans Seeded');
  } else {
    console.log('ℹ️ Weight Loss Plans already exist');
  }
};

module.exports = seedWeightLossPlansIfNeeded;
