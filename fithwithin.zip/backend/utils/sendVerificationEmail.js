const nodemailer = require('nodemailer');

const sendVerificationEmail = async (email, link) => {
  try {
    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: process.env.EMAIL_USER,      // e.g., your Gmail address
        pass: process.env.EMAIL_PASS,      // e.g., your Gmail app password
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Verify your email',
      html: `
        <h2>Welcome!</h2>
        <p>Please click the link below to verify your email:</p>
        <a href="${link}">${link}</a>
        <p>This link expires in 60 days.</p>
      `,
    };

    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Email sending error:', error);
    throw new Error('Failed to send verification email');
  }
};

module.exports = sendVerificationEmail;
